# Shizuku 相关类保留（反射/服务在 Shizuku 进程中加载）
-keep class rikka.shizuku.** { *; }
-keep class dev.rikka.shizuku.** { *; }
-keep class com.gamepadmouse.shizuku.ShellInputService { *; }
-keep class com.gamepadmouse.input.** { *; }
