package com.gamepadmouse.input;

/**
 * 输入注入接口。
 * 该接口由运行在 Shizuku（shell 权限）进程中的 ShellInputService 实现，
 * 客户端（应用进程）通过 Shizuku.bindService 获取并调用。
 */
interface IInputInjector {
    /** 左键单击 */
    void click(int x, int y);
    /** 右键单击（鼠标 BUTTON_SECONDARY） */
    void rightClick(int x, int y);
    /** 中键单击（鼠标 BUTTON_TERTIARY） */
    void middleClick(int x, int y);
    /** 移动鼠标指针（hover） */
    void movePointer(int x, int y);
    /** 滚轮滚动，amount 为正向下滚、负向上滚 */
    void scroll(int x, int y, float amount);
    /** 触摸按下（拖拽用 / 左键按住） */
    void touchDown(int x, int y);
    /** 触摸移动（拖拽用） */
    void touchMove(int x, int y);
    /** 触摸抬起（拖拽用 / 左键松开） */
    void touchUp();
    /** 右键按住（鼠标 BUTTON_SECONDARY 按下，长按右键） */
    void rightDown(int x, int y);
    /** 右键松开（BUTTON_SECONDARY 抬起） */
    void rightUp();
    /** 注入系统按键（如 KEYCODE_APP_SWITCH） */
    void key(int keyCode);
}
