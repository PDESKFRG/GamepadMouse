package com.gamepadmouse.app;

import android.app.Application;
import android.os.Build;

import com.gamepadmouse.app.crash.CrashHandler;

public class App extends Application {

    private static App sInstance;

    public static App get() {
        return sInstance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        sInstance = this;
        // 全局防闪退：记录所有未捕获异常，并尝试恢复
        CrashHandler.install(this);
        // Shizuku 依赖在 8.0+ 上要求高版本 API；这里仅为兼容性占位
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // no-op
        }
    }
}
