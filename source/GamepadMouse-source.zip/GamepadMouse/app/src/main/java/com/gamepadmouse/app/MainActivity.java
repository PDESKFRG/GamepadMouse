package com.gamepadmouse.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.gamepadmouse.app.core.GamepadMouseService;
import com.gamepadmouse.app.crash.CrashHandler;
import com.gamepadmouse.app.util.Prefs;
import com.gamepadmouse.shizuku.ShizukuManager;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_SHIZUKU = 101;
    private static final int REQ_NOTIFICATION = 102;

    private TextView mOverlayStatus;
    private TextView mShizukuStatus;
    private TextView mA11yStatus;
    private TextView mBackendStatus;
    private TextView mSensValue;
    private TextView mSwipeValue;
    private TextView mDeadzoneValue;
    private TextView mL2MsValue;
    private TextView mCursorValue;
    private SeekBar mSensBar;
    private SeekBar mSwipeBar;
    private SeekBar mDeadzoneBar;
    private SeekBar mL2MsBar;
    private SeekBar mCursorBar;
    private Button mStartBtn;
    private final Handler mUiHandler = new Handler(Looper.getMainLooper());
    private final Runnable mStatusRefresher = new Runnable() {
        @Override
        public void run() {
            refreshStatus();
            mUiHandler.postDelayed(this, 2000); // 每 2 秒实时刷新权限/后端状态
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mOverlayStatus = findViewById(R.id.status_overlay);
        mShizukuStatus = findViewById(R.id.status_shizuku);
        mA11yStatus = findViewById(R.id.status_a11y);
        mBackendStatus = findViewById(R.id.status_backend);
        mSensValue = findViewById(R.id.sens_value);
        mSwipeValue = findViewById(R.id.swipe_value);
        mDeadzoneValue = findViewById(R.id.deadzone_value);
        mL2MsValue = findViewById(R.id.l2ms_value);
        mCursorValue = findViewById(R.id.cursor_value);
        mSensBar = findViewById(R.id.sens_bar);
        mSwipeBar = findViewById(R.id.swipe_bar);
        mDeadzoneBar = findViewById(R.id.deadzone_bar);
        mL2MsBar = findViewById(R.id.l2ms_bar);
        mCursorBar = findViewById(R.id.cursor_bar);
        mStartBtn = findViewById(R.id.btn_start);

        findViewById(R.id.btn_overlay).setOnClickListener(v -> {
            if (Settings.canDrawOverlays(this)) {
                toast("悬浮窗权限已开启");
            } else {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            }
        });

        findViewById(R.id.btn_shizuku).setOnClickListener(v -> handleShizukuButton());

        findViewById(R.id.btn_a11y).setOnClickListener(v -> {
            if (isAccessibilityEnabled()) {
                toast("无障碍服务已开启");
            } else {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });

        mStartBtn.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                new AlertDialog.Builder(this)
                        .setTitle("需要悬浮窗权限")
                        .setMessage("“手柄鼠标”需要悬浮窗权限来显示鼠标光标。\n\n也可以在电脑上用无线调试执行：\n" +
                                "adb shell appops set " + getPackageName() + " SYSTEM_ALERT_WINDOW allow\n\n" +
                                "现在前往系统设置开启？")
                        .setPositiveButton("去开启", (d, w) -> startActivity(
                                new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:" + getPackageName()))))
                        .setNegativeButton("取消", null)
                        .show();
                return;
            }
            if (GamepadMouseService.isRunning()) {
                startService(new Intent(this, GamepadMouseService.class)
                        .setAction(GamepadMouseService.ACTION_STOP));
                refreshStatus();
                return;
            }
            // 注入通道全无（Shizuku 未运行 且 无障碍未开）：先说明，避免“启动了但点不动”
            if (!ShizukuManager.isShizukuAvailable() && !isAccessibilityEnabled()) {
                new AlertDialog.Builder(this)
                        .setTitle("两条注入通道都没开")
                        .setMessage("Shizuku 服务未运行，无障碍注入也未开启——即使启动鼠标模式，点击也不会生效。\n\n" +
                                "最快方案：先开「无障碍注入」（设置→无障碍→手柄鼠标），立即能用；\n" +
                                "要真实左/右/中键：用下方「用无线调试启动 Shizuku」。")
                        .setPositiveButton("先去开无障碍", (d, w) -> startActivity(
                                new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                        .setNegativeButton("继续启动", (d, w) -> startMouseMode())
                        .show();
                return;
            }
            // Shizuku 已授权但服务没在运行：最常见困惑点，先解释清楚再启动
            // （授权 ≠ Shizuku 正在运行；重启手机后需重新启动 Shizuku）
            if (ShizukuManager.hasPermission() && !ShizukuManager.isShizukuAvailable()) {
                new AlertDialog.Builder(this)
                        .setTitle("Shizuku 未在运行")
                        .setMessage("你已授权过 Shizuku，但它当前没有运行（重启手机后需重新启动）。\n\n" +
                                "本次会先用「无障碍注入」兜底；想用真实左/右/中键，请先打开 Shizuku App 点启动。")
                        .setPositiveButton("继续启动", (d, w) -> startMouseMode())
                        .setNegativeButton("打开 Shizuku", (d, w) -> launchShizukuApp())
                        .show();
                return;
            }
            startMouseMode();
            refreshStatus();
        });

        findViewById(R.id.btn_crash_log).setOnClickListener(v -> showCrashLog());
        findViewById(R.id.btn_copy_log).setOnClickListener(v -> copyCrashLog());
        findViewById(R.id.btn_wireless_start).setOnClickListener(v -> showWirelessStartGuide());
        findViewById(R.id.btn_mapping).setOnClickListener(v -> showMappingDialog());

        mSensBar.setProgress(Prefs.getSensitivity(this));
        // 右摇杆滑动距离：滑条 0..20 → 3.0..5.0 cm
        float cm = Prefs.getSwipeDistanceCm(this);
        mSwipeBar.setProgress(Math.round((cm - 3.0f) * 10));
        // 摇杆死区：滑条 0..25 → 0.05..0.30
        float dead = Prefs.getStickDeadzone(this);
        mDeadzoneBar.setProgress(Math.round((dead - 0.05f) * 100));
        // L2 单击判定阈值：滑条 0..45 → 50..500 ms
        mL2MsBar.setProgress(Math.round((Prefs.getL2ClickMs(this) - 50) / 10f));
        mSensBar.setOnSeekBarChangeListener(new SimpleBar() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int v = Math.max(2, progress);
                Prefs.setSensitivity(MainActivity.this, v);
                mSensValue.setText(v + "");
            }
        });
        mSwipeBar.setOnSeekBarChangeListener(new SimpleBar() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float v = 3.0f + progress * 0.1f; // 3.0..5.0 cm
                Prefs.setSwipeDistanceCm(MainActivity.this, v);
                mSwipeValue.setText(String.format(java.util.Locale.US, "%.1f cm", v));
            }
        });
        mDeadzoneBar.setOnSeekBarChangeListener(new SimpleBar() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float v = 0.05f + progress * 0.01f; // 0.05..0.30
                Prefs.setStickDeadzone(MainActivity.this, v);
                mDeadzoneValue.setText(String.format(java.util.Locale.US, "%.2f", v));
            }
        });
        mL2MsBar.setOnSeekBarChangeListener(new SimpleBar() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int v = 50 + progress * 10; // 50..500 ms
                Prefs.setL2ClickMs(MainActivity.this, v);
                mL2MsValue.setText(v + " ms");
            }
        });
        mSensValue.setText(Prefs.getSensitivity(this) + "");
        mSwipeValue.setText(String.format(java.util.Locale.US, "%.1f cm", Prefs.getSwipeDistanceCm(this)));
        mDeadzoneValue.setText(String.format(java.util.Locale.US, "%.2f", Prefs.getStickDeadzone(this)));
        mL2MsValue.setText(Prefs.getL2ClickMs(this) + " ms");

        // 光标大小：progress 0..46 对应 10..56 dp
        int cursorSize = Prefs.getCursorSize(this);
        mCursorBar.setProgress(cursorSize - 10);
        mCursorValue.setText(cursorSize + "");
        mCursorBar.setOnSeekBarChangeListener(new SimpleBar() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int size = progress + 10;
                Prefs.setCursorSize(MainActivity.this, size);
                mCursorValue.setText(size + "");
                GamepadMouseService s = GamepadMouseService.get();
                if (s != null) s.refreshCursorSize();
            }
        });

        // Android 13+ 通知权限（前台服务通知）
        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATION);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 回到界面时静默重试 Shizuku 绑定/后端切换，并刷新显示
        GamepadMouseService.recheckBackend(false);
        refreshStatus();
        // 实时检测权限与后端状态：每 2 秒刷新一次（Shizuku 授权/运行、无障碍开关状态实时反映）
        mUiHandler.removeCallbacks(mStatusRefresher);
        mUiHandler.post(mStatusRefresher);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mUiHandler.removeCallbacks(mStatusRefresher);
    }

    private void refreshStatus() {
        boolean overlay = Settings.canDrawOverlays(this);
        setStatus(mOverlayStatus, overlay, "悬浮窗权限：" + (overlay ? "已开启" : "未开启"));

        boolean shizukuReady = ShizukuManager.isShizukuAvailable();
        boolean shizukuPerm = shizukuReady && ShizukuManager.hasPermission();
        String shizukuText = shizukuReady
                ? (shizukuPerm ? "Shizuku：已授权" : "Shizuku：未授权（点击授权）")
                : "Shizuku：未运行（点击查看开启方法）";
        setStatus(mShizukuStatus, shizukuPerm, shizukuText);

        boolean a11y = isAccessibilityEnabled();
        setStatus(mA11yStatus, a11y, "无障碍注入：" + (a11y ? "已开启" : "未开启（兜底方案）"));

        GamepadMouseService s = GamepadMouseService.get();
        String backendName = (s != null) ? s.getBackendName() : "未运行";
        if (s == null) {
            setStatus(mBackendStatus, false, "注入后端：未运行（请先点「启动鼠标模式」）");
        } else if ("Shizuku".equals(backendName)) {
            setStatus(mBackendStatus, true, "注入后端：Shizuku ✓");
        } else if ("无障碍".equals(backendName)) {
            setStatus(mBackendStatus, true, "注入后端：无障碍 ✓（右键/中键为降级手势）");
        } else {
            // 详细诊断：把没连上的原因说清楚
            StringBuilder why = new StringBuilder("注入后端：未连接");
            if (ShizukuManager.isShizukuAvailable()) {
                if (ShizukuManager.hasPermission()) {
                    String err = ShizukuManager.getLastError();
                    if (err != null && !err.isEmpty()) {
                        why.append("（").append(err).append("）");
                    } else {
                        why.append("（Shizuku 绑定中…请稍候，会自动重试）");
                    }
                } else {
                    why.append("（Shizuku 未授权：点上方 Shizuku 授权）");
                }
            } else {
                why.append("（Shizuku 未运行：打开 Shizuku App 启动，或用无障碍兜底）");
            }
            setStatus(mBackendStatus, false, why.toString());
        }

        mStartBtn.setText(GamepadMouseService.isRunning() ? "■ 停止鼠标模式" : "▶ 启动鼠标模式");
    }

    private void setStatus(TextView tv, boolean ok, String text) {
        tv.setText(text);
        tv.setTextColor(ContextCompat.getColor(this,
                ok ? R.color.ok_green : R.color.warn_orange));
    }

    /** 正式启动鼠标模式：起服务 + 1.5s 自检 + OriginOS 后台限制首次提示 */
    private void startMouseMode() {
        try {
            startService(new Intent(this, GamepadMouseService.class)
                    .setAction(GamepadMouseService.ACTION_START));
        } catch (Throwable t) {
            toast("启动失败：" + t.getClass().getSimpleName() + "（请关闭本应用的「后台限制/智能省电」后重试）");
            return;
        }
        // 启动结果自检：服务没起来 / 起了但注入后端没连上，都给出可操作提示
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
            try {
                GamepadMouseService s = GamepadMouseService.get();
                if (s == null || !GamepadMouseService.isRunning()) {
                    toast("鼠标模式未启动：请确认已授予悬浮窗权限"
                            + "（vivo/OPPO 等机型需在「应用→特殊应用权限」开启），并关闭本应用后台限制");
                } else if ("未连接".equals(s.getBackendName())) {
                    toast("光标已出现，但注入后端未连接：请启动 Shizuku 或开启无障碍注入，点击才会生效");
                }
            } catch (Throwable ignored) {
            }
            refreshStatus();
        }, 1500);
        // OriginOS（vivo/iQOO）默认限制侧载应用后台，悬浮窗易被系统清理：首次启动提示一次
        if (!Prefs.getBgLimitHintShown(this)) {
            Prefs.setBgLimitHintShown(this, true);
            new AlertDialog.Builder(this)
                    .setTitle("给本应用关闭后台限制（vivo/iQOO 必做）")
                    .setMessage("否则 OriginOS 会清理悬浮窗，鼠标模式随时可能失效。\n\n" +
                            "设置 → 应用与权限 → 应用管理 → 手柄鼠标 → 耗电管理 → 关闭「智能省电/后台限制」，并允许后台活动。")
                    .setPositiveButton("知道了", null)
                    .show();
        }
    }

    private void handleShizukuButton() {
        if (!ShizukuManager.isShizukuAvailable()) {
            new AlertDialog.Builder(this)
                    .setTitle("未检测到 Shizuku")
                    .setMessage("Shizuku 是本软件实现真实鼠标左/右/中键的推荐通道。\n\n开启方法：\n" +
                            "1. 安装 Shizuku App（https://shizuku.rikka.app）；\n" +
                            "2. 手机开启“开发者选项 → 无线调试”，按 Shizuku 内指引配对启动；\n" +
                            "3. 回到本软件点击“授权”。\n\n" +
                            "若不方便安装，也可改用“无障碍注入”（点击下方无障碍按钮开启），但右键/中键为降级手势。")
                    .setPositiveButton("去了解", (d, w) -> startActivity(ShizukuManager.getShizukuGuideIntent()))
                    .setNegativeButton("取消", null)
                    .show();
            return;
        }
        if (ShizukuManager.hasPermission()) {
            toast("Shizuku 已授权");
            return;
        }
        ShizukuManager.requestPermission(REQ_SHIZUKU);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_SHIZUKU) {
            boolean granted = grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            toast(granted ? "Shizuku 授权成功" : "未授予 Shizuku 权限");
            refreshStatus();
        }
    }

    private boolean isAccessibilityEnabled() {
        try {
            String enabled = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (TextUtils.isEmpty(enabled)) return false;
            ComponentName cn = new ComponentName(this,
                    "com.gamepadmouse.app.access.GamepadAccessibilityService");
            String flat = cn.flattenToString();
            for (String s : enabled.split(":")) {
                if (s.equalsIgnoreCase(flat)) return true;
            }
            return false;
        } catch (Throwable t) {
            return false;
        }
    }

    // ---------------- 按键自定义 ----------------
    // 顺序必须与 Prefs.ACTION_* 常量值一一对应
    private static final String[] ACTION_NAMES = {
            "无动作",                                  // 0 NONE
            "左键单击",                                // 1 LEFT_CLICK
            "右键单击",                                // 2 RIGHT_CLICK
            "中键单击",                                // 3 MIDDLE_CLICK
            "左键（单击/长按/拖动）",                   // 4 LEFT_HOLD
            "右键（短按点击/长按）",                     // 5 RIGHT_HOLD
            "滚轮上",                                  // 6 SCROLL_UP
            "滚轮下",                                  // 7 SCROLL_DOWN
            "拖拽切换",                                // 8 DRAG_TOGGLE
            "按住拖拽（按下开始/松开结束）",             // 9 HOLD_DRAG
            "退出鼠标模式",                            // 10 EXIT
            "最近任务",                                // 11 RECENTS
            "返回",                                    // 12 BACK
            "手指上滑",                                // 13 SWIPE_UP
            "手指下滑",                                // 14 SWIPE_DOWN
            "手指左滑",                                // 15 SWIPE_LEFT
            "手指右滑",                                // 16 SWIPE_RIGHT
            "十字键微调"                               // 17 DPAD
    };

    private void showMappingDialog() {
        new AlertDialog.Builder(this)
                .setTitle("自定义按键 · 点击按键选动作")
                .setItems(Prefs.MAPPABLE_KEY_NAMES, (d, which) ->
                        pickAction(Prefs.MAPPABLE_KEY_NAMES[which], Prefs.MAPPABLE_KEYS[which]))
                .setNeutralButton("恢复默认", (d, w) -> {
                    Prefs.resetButtonActions(this);
                    toast("按键映射已恢复默认");
                })
                .show();
    }

    private void pickAction(String keyName, int keyCode) {
        int cur = Prefs.getButtonAction(this, keyCode);
        new AlertDialog.Builder(this)
                .setTitle(keyName + " 设为：")
                .setSingleChoiceItems(ACTION_NAMES, cur, (d, w) -> {
                    Prefs.setButtonAction(this, keyCode, w);
                    toast(keyName + " → " + ACTION_NAMES[w]);
                    d.dismiss();
                })
                .show();
    }

    private void showCrashLog() {
        String log = CrashHandler.readCrashLog(this);
        if (TextUtils.isEmpty(log)) {
            toast("暂无崩溃日志（说明运行稳定）");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("崩溃日志")
                .setMessage(log)
                .setPositiveButton("关闭", null)
                .setNegativeButton("清除日志", (d, w) -> {
                    CrashHandler.clearCrashLog(this);
                    toast("已清除");
                })
                .setNeutralButton("复制日志", (d, w) -> copyCrashLog())
                .show();
    }

    /** 一键复制崩溃日志到剪贴板，方便直接粘贴给开发者排查 */
    private void copyCrashLog() {
        try {
            String log = CrashHandler.readCrashLog(this);
            if (TextUtils.isEmpty(log)) {
                toast("暂无崩溃日志（说明运行稳定）");
                return;
            }
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("gamepad_mouse_crash", log));
            toast("崩溃日志已复制，可直接粘贴发送");
        } catch (Throwable t) {
            toast("复制失败：" + t.getMessage());
        }
    }

    /** 无线调试启动 Shizuku 引导：授权 ≠ 运行，重启手机后需重新启动 Shizuku 服务 */
    private void showWirelessStartGuide() {
        new AlertDialog.Builder(this)
                .setTitle("用无线调试启动 Shizuku")
                .setMessage("「Shizuku: 已授权」只代表授权过；Shizuku 服务没在运行时仍然连不上。" +
                        "重启手机 / 被系统清理后都要重新启动一次。\n\n" +
                        "步骤：\n" +
                        "1. 设置 → 开发者选项 → 打开「无线调试」\n" +
                        "2. 打开 Shizuku App → 点「无线调试」→ 点「配对」→ 输入系统弹出的配对码\n" +
                        "3. 配对成功后在 Shizuku 里点「启动」（状态变为已启动/运行中）\n" +
                        "4. 回到本 App，状态应显示「后端: Shizuku」\n\n" +
                        "不想用 Shizuku？开「无障碍注入」也能立即点击（右键/中键为降级手势）。")
                .setPositiveButton("打开 Shizuku App", (d, w) -> launchShizukuApp())
                .setNeutralButton("去开无线调试", (d, w) -> openWirelessDebugSetting())
                .setNegativeButton("取消", null)
                .show();
    }

    private void launchShizukuApp() {
        try {
            Intent i = new Intent("moe.shizuku.manager.intent.action.MAIN");
            i.addCategory(Intent.CATEGORY_LAUNCHER);
            i.setPackage("moe.shizuku.manager");
            startActivity(i);
        } catch (Throwable t) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://shizuku.rikka.app/zh-hans/download/")));
            } catch (Throwable t2) {
                toast("未找到 Shizuku App，请先安装（shizuku.rikka.app）");
            }
        }
    }

    private void openWirelessDebugSetting() {
        try {
            // 无线调试子页无公开 Intent，跳开发者选项页（含无线调试入口）
            startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));
        } catch (Throwable t) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (Throwable t2) {
                toast("请在系统设置中手动打开「开发者选项 → 无线调试」");
            }
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private abstract static class SimpleBar implements SeekBar.OnSeekBarChangeListener {
        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
        }
    }
}
