package com.gamepadmouse.app.access;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;

import com.gamepadmouse.app.core.GamepadMouseService;

/**
 * 无障碍注入兜底服务。
 * 无需 Shizuku：开启本服务后，可用 dispatchGesture 模拟点击/长按/滑动。
 * 说明（无障碍模式下按键能力降级）：
 *  - 左键 = 单击
 *  - 右键 = 长按 500ms（代替右键）
 *  - 中键 = 双指轻点（代替中键）
 *  - 滚动 = 上下滑动
 * 不读取任何屏幕内容（canRetrieveWindowContent=false）。
 */
public class GamepadAccessibilityService extends AccessibilityService {

    private static final String TAG = "AccessService";
    private static volatile GamepadAccessibilityService sInstance;

    public static boolean isConnected() {
        return sInstance != null;
    }

    /** 单击（左键） */
    public static boolean tap(int x, int y) {
        return performGesture(x, y, 50, false);
    }

    /** 长按（代替右键） */
    public static boolean longPress(int x, int y) {
        return performGesture(x, y, 500, false);
    }

    /** 双指轻点（代替中键） */
    public static boolean doubleFingerTap(int x, int y) {
        return performGesture(x, y, 50, true);
    }

    /** 垂直滑动（代替滚轮） */
    public static boolean swipe(int x, int y, float amount) {
        GamepadAccessibilityService s = sInstance;
        if (s == null) return false;
        try {
            Path p = new Path();
            p.moveTo(x, y);
            float dy = amount > 0 ? -300 : 300;
            p.lineTo(x, Math.max(0, Math.min(s.getResources().getDisplayMetrics().heightPixels - 1, y + dy)));
            GestureDescription gd = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(p, 0, 150))
                    .build();
            return s.dispatchGesture(gd, null, null);
        } catch (Throwable t) {
            Log.w(TAG, "swipe failed: " + t);
            return false;
        }
    }

    /** 按方向与像素距离滑动（右摇杆手势：从 (x,y) 向 (dx,dy) 方向自然滑动手势） */
    public static boolean swipeVector(int fromX, int fromY, float dx, float dy) {
        GamepadAccessibilityService s = sInstance;
        if (s == null) return false;
        try {
            int toX = (int) (fromX + dx);
            int toY = (int) (fromY + dy);
            int w = s.getResources().getDisplayMetrics().widthPixels - 1;
            int h = s.getResources().getDisplayMetrics().heightPixels - 1;
            toX = Math.max(0, Math.min(w, toX));
            toY = Math.max(0, Math.min(h, toY));
            Path p = new Path();
            p.moveTo(fromX, fromY);
            p.lineTo(toX, toY);
            GestureDescription gd = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(p, 0, 180))
                    .build();
            return s.dispatchGesture(gd, null, null);
        } catch (Throwable t) {
            Log.w(TAG, "swipeVector failed: " + t);
            return false;
        }
    }

    private static boolean performGesture(int x, int y, int duration, boolean twoFinger) {
        GamepadAccessibilityService s = sInstance;
        if (s == null) return false;
        try {
            GestureDescription.Builder builder = new GestureDescription.Builder();
            Path p = new Path();
            p.moveTo(x, y);
            builder.addStroke(new GestureDescription.StrokeDescription(p, 0, duration));
            if (twoFinger) {
                Path p2 = new Path();
                p2.moveTo(x + 80, y + 80);
                builder.addStroke(new GestureDescription.StrokeDescription(p2, 0, duration));
            }
            return s.dispatchGesture(builder.build(), null, null);
        } catch (Throwable t) {
            Log.w(TAG, "gesture failed: " + t);
            return false;
        }
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        sInstance = this;
        Log.i(TAG, "accessibility service connected");
        // 无障碍刚开启：通知鼠标服务立即切换注入后端（无需重启鼠标模式）
        GamepadMouseService.recheckBackend(true);
    }

    @Override
    public void onDestroy() {
        sInstance = null;
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // 无需处理任何事件
    }

    @Override
    public void onInterrupt() {
    }
}
