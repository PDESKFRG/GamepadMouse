package com.gamepadmouse.app.core;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.Log;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import com.gamepadmouse.app.util.GamepadInputMath;
import com.gamepadmouse.app.util.Prefs;

/**
 * 悬浮光标视图。
 * 职责：
 *  1. 接收手柄输入（摇杆轴 + 按键），转换成语义动作回调给服务；
 *  2. 绘制鼠标光标。
 * 所有输入处理都包异常防护；坐标始终钳制在屏幕范围内。
 */
public class CursorOverlayView extends View {

    private static final String TAG = "CursorOverlayView";

    // 摇杆死区

    public interface Listener {
        void onPrimaryClick();        // 左键单击
        void onSecondaryClick();      // 右键单击
        void onMiddleClick();         // 中键单击
        void onPrimaryDown();         // 左键按住（按下）
        void onPrimaryUp();           // 左键按住（松开）
        void onSecondaryDown();       // 右键按住（按下）
        void onSecondaryUp();         // 右键按住（松开）
        void onDragChanged(boolean down); // 拖拽
        void onDiscreteScroll(float amount); // 滚轮
        void onBoostChanged(boolean on); // 保留：不再使用
        void onSlowChanged(boolean on);   // 保留：不再使用
        void onExitRequested();       // 退出鼠标模式
        void onMenuRequested();       // 最近任务
        void onBackRequested();       // 系统返回
        void onSwipeGesture(float dx, float dy); // 手指滑动方向手势（自定义动作）
        void onToggleStick();         // 切换拖拽
        void onDpad(float dx, float dy); // 十字键微调（down=true 时调用）
    }

    private Listener mListener;

    // 摇杆状态（由 onGenericMotionEvent 更新，服务每帧轮询）
    private volatile float mStickX;
    private volatile float mStickY;
    private volatile float mRightStickX;
    private volatile float mRightStickY;

    // 扳机状态：上一帧是否按下（用于按下/松开边沿触发）
    private boolean mLeftTriggerDown;
    private boolean mRightTriggerDown;

    // 光标位置（视图坐标 = 屏幕坐标）
    private float mCursorX;
    private float mCursorY;
    private int mScreenW = 1080;
    private int mScreenH = 1920;

    // 状态标志
    private boolean mDragMode;

    // 右下角状态文字（由服务设置：注入后端状态）
    private volatile String mStatusText = "";

    // 画笔
    private final Paint mFill;
    private final Paint mRing;
    private final Paint mDragRing;
    private final Paint mLabel;
    private final Path mArrow;
    private float mCursorSizeDp;

    public CursorOverlayView(Context context) {
        super(context);
        setFocusable(true);
        setFocusableInTouchMode(true);

        mCursorSizeDp = Prefs.getCursorSize(context);

        mFill = new Paint(Paint.ANTI_ALIAS_FLAG);
        mFill.setColor(Color.WHITE);

        mRing = new Paint(Paint.ANTI_ALIAS_FLAG);
        mRing.setStyle(Paint.Style.STROKE);
        mRing.setStrokeWidth(2 * dp(1));
        mRing.setColor(Color.BLACK);

        mDragRing = new Paint(Paint.ANTI_ALIAS_FLAG);
        mDragRing.setStyle(Paint.Style.STROKE);
        mDragRing.setStrokeWidth(3 * dp(1));
        mDragRing.setColor(Color.rgb(255, 165, 0));

        mLabel = new Paint(Paint.ANTI_ALIAS_FLAG);
        mLabel.setColor(Color.argb(220, 15, 23, 42));
        mLabel.setTextSize(12 * dp(1));

        // 复用箭头路径，避免每帧分配
        mArrow = new Path();
    }

    /** 重新读取光标大小设置（设置变更后调用） */
    public void refreshCursorSize() {
        mCursorSizeDp = Prefs.getCursorSize(getContext());
        invalidate();
    }

    /** 设置右下角状态文字（注入后端状态等） */
    public void setStatusText(String text) {
        mStatusText = text == null ? "" : text;
        invalidate();
    }

    // 悬浮窗在屏幕上的实际位置（部分 ROM 窗口不从 (0,0) 开始，例如 OriginOS 状态栏下方）
    private int mScreenOffsetX;
    private int mScreenOffsetY;

    /** 布局完成后 / 周期调用：读取悬浮窗窗口在屏幕上的偏移，用于注入坐标补偿 */
    public void refreshScreenOffset() {
        try {
            int[] loc = new int[2];
            getLocationOnScreen(loc);
            mScreenOffsetX = loc[0];
            mScreenOffsetY = loc[1];
        } catch (Throwable t) {
            Log.w(TAG, "refreshScreenOffset error: " + t);
        }
    }

    /** 光标在屏幕上的实际 X（窗口内坐标 + 窗口屏幕偏移），供注入使用 */
    public float getScreenCursorX() {
        return mCursorX + mScreenOffsetX;
    }

    /** 光标在屏幕上的实际 Y（窗口内坐标 + 窗口屏幕偏移），供注入使用 */
    public float getScreenCursorY() {
        return mCursorY + mScreenOffsetY;
    }

    public void setListener(Listener l) {
        mListener = l;
    }

    public void setScreenSize(int w, int h) {
        mScreenW = Math.max(w, 1);
        mScreenH = Math.max(h, 1);
        // 若光标在屏外则拉回
        mCursorX = Math.max(0, Math.min(mCursorX, mScreenW - 1));
        mCursorY = Math.max(0, Math.min(mCursorY, mScreenH - 1));
    }

    public void centerCursor() {
        mCursorX = mScreenW / 2f;
        mCursorY = mScreenH / 2f;
        invalidate();
    }

    public float getCursorX() {
        return mCursorX;
    }

    public float getCursorY() {
        return mCursorY;
    }

    public float getStickX() {
        return mStickX;
    }

    public float getStickY() {
        return mStickY;
    }

    public float getRightStickY() {
        return mRightStickY;
    }

    public float getRightStickX() {
        return mRightStickX;
    }

    public boolean isDragMode() {
        return mDragMode;
    }

    public void setDragMode(boolean drag) {
        mDragMode = drag;
        invalidate();
    }

    /** 按帧移动光标（已含曲线整形），返回是否移动了 */
    public void moveBy(float dx, float dy) {
        mCursorX = clamp(mCursorX + dx, 0, mScreenW - 1);
        mCursorY = clamp(mCursorY + dy, 0, mScreenH - 1);
        invalidate();
    }

    public void moveDpad(float dx, float dy) {
        mCursorX = clamp(mCursorX + dx, 0, mScreenW - 1);
        mCursorY = clamp(mCursorY + dy, 0, mScreenH - 1);
        invalidate();
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    // ---------------- 输入 ----------------

    @Override
    public boolean onGenericMotionEvent(MotionEvent ev) {
        try {
            // 鼠标模式：所有通用事件一律消费，不泄漏给系统/其他应用
            int source = ev.getSource();
            if ((source & InputDevice.SOURCE_CLASS_JOYSTICK) != 0) {
                boolean swap = Prefs.getSwapSticks(getContext());

                // 左摇杆：标准 AXIS_X / AXIS_Y
                float rawX = ev.getAxisValue(MotionEvent.AXIS_X);
                float rawY = ev.getAxisValue(MotionEvent.AXIS_Y);

                // 右摇杆兼容两种映射：
                //  索尼/微软布局：AXIS_RX / AXIS_RY
                //  国产/部分蓝牙手柄：AXIS_Z(右X) / AXIS_RZ(右Y)
                // 用幅值比较自动选择实际有信号的那一组轴，避免“声明了 RX/RY 但实际用 Z/RZ”的手柄失效
                float vRX = ev.getAxisValue(MotionEvent.AXIS_RX);
                float vRY = ev.getAxisValue(MotionEvent.AXIS_RY);
                float vZ = ev.getAxisValue(MotionEvent.AXIS_Z);
                float vRZ = ev.getAxisValue(MotionEvent.AXIS_RZ);
                float[] right = GamepadInputMath.chooseRightStick(vRX, vRY, vZ, vRZ);
                float rightX = right[0];
                float rightY = right[1];

                if (swap) {
                    mStickX = GamepadInputMath.normalizeAxis(rightX);
                    mStickY = GamepadInputMath.normalizeAxis(rightY);
                    mRightStickX = GamepadInputMath.normalizeAxis(rawX);
                    mRightStickY = GamepadInputMath.normalizeAxis(rawY);
                } else {
                    mStickX = GamepadInputMath.normalizeAxis(rawX);
                    mStickY = GamepadInputMath.normalizeAxis(rawY);
                    mRightStickX = GamepadInputMath.normalizeAxis(rightX);
                    mRightStickY = GamepadInputMath.normalizeAxis(rightY);
                }
                if (Prefs.getInvertY(getContext())) {
                    mStickY = -mStickY;
                }
                // 扳机 = 鼠标左右键（按下/松开边沿，短按=点击、长按=长按）
                // 动作由按键映射决定（默认 L2=左键按住、R2=右键按住）
                Listener l = mListener;
                float lt = ev.getAxisValue(MotionEvent.AXIS_LTRIGGER);
                float rt = ev.getAxisValue(MotionEvent.AXIS_RTRIGGER);
                boolean ltDown = lt > 0.5f;
                boolean rtDown = rt > 0.5f;
                if (ltDown != mLeftTriggerDown) {
                    dispatchAction(Prefs.getButtonAction(getContext(), KeyEvent.KEYCODE_BUTTON_L2),
                            KeyEvent.KEYCODE_BUTTON_L2, ltDown);
                }
                if (rtDown != mRightTriggerDown) {
                    dispatchAction(Prefs.getButtonAction(getContext(), KeyEvent.KEYCODE_BUTTON_R2),
                            KeyEvent.KEYCODE_BUTTON_R2, rtDown);
                }
                mLeftTriggerDown = ltDown;
                mRightTriggerDown = rtDown;
            }
            return true; // 全消费
        } catch (Throwable t) {
            Log.w(TAG, "generic motion error: " + t);
        }
        return true;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        try {
            if (event.getRepeatCount() == 0) {
                handleButton(keyCode, true);
            }
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "key down error: " + t);
        }
        return true;
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        try {
            handleButton(keyCode, false);
        } catch (Throwable t) {
            Log.w(TAG, "key up error: " + t);
        }
        return true;
    }

    private void handleButton(int keyCode, boolean down) {
        // 所有按键（含十字键）统一走自定义映射；BACK 默认=系统返回
        dispatchAction(Prefs.getButtonAction(getContext(), keyCode), keyCode, down);
    }

    /**
     * 按键动作分发（按下/松开语义）。
     *  - CLICK 类动作：只在按下瞬间触发一次；
     *  - HOLD 类动作：按下=按住，松开=松开（短按即一次完整点击，长按即长按）；
     *  - DPAD：十字键微调（带方向）。
     */
    private void dispatchAction(int action, int keyCode, boolean down) {
        Listener l = mListener;
        switch (action) {
            case Prefs.ACTION_LEFT_CLICK:
                if (down && l != null) l.onPrimaryClick();
                break;
            case Prefs.ACTION_RIGHT_CLICK:
                if (down && l != null) l.onSecondaryClick();
                break;
            case Prefs.ACTION_MIDDLE_CLICK:
                if (down && l != null) l.onMiddleClick();
                break;
            case Prefs.ACTION_LEFT_HOLD:
                if (l != null) {
                    if (down) l.onPrimaryDown();
                    else l.onPrimaryUp();
                }
                break;
            case Prefs.ACTION_RIGHT_HOLD:
                if (l != null) {
                    if (down) l.onSecondaryDown();
                    else l.onSecondaryUp();
                }
                break;
            case Prefs.ACTION_SCROLL_UP:
                if (down && l != null) l.onDiscreteScroll(-1f);
                break;
            case Prefs.ACTION_SCROLL_DOWN:
                if (down && l != null) l.onDiscreteScroll(1f);
                break;
            case Prefs.ACTION_DRAG_TOGGLE:
                if (down && l != null) l.onToggleStick();
                break;
            case Prefs.ACTION_HOLD_DRAG:
                if (l != null) l.onDragChanged(down);
                break;
            case Prefs.ACTION_EXIT:
                if (down && l != null) l.onExitRequested();
                break;
            case Prefs.ACTION_RECENTS:
                if (down && l != null) l.onMenuRequested();
                break;
            case Prefs.ACTION_BACK:
                if (down && l != null) l.onBackRequested();
                break;
            case Prefs.ACTION_SWIPE_UP:
                if (down && l != null) l.onSwipeGesture(0f, -1f);
                break;
            case Prefs.ACTION_SWIPE_DOWN:
                if (down && l != null) l.onSwipeGesture(0f, 1f);
                break;
            case Prefs.ACTION_SWIPE_LEFT:
                if (down && l != null) l.onSwipeGesture(-1f, 0f);
                break;
            case Prefs.ACTION_SWIPE_RIGHT:
                if (down && l != null) l.onSwipeGesture(1f, 0f);
                break;
            case Prefs.ACTION_DPAD:
                if (l != null) {
                    float dx = 0f, dy = 0f;
                    switch (keyCode) {
                        case KeyEvent.KEYCODE_DPAD_UP:
                            dy = down ? -1f : 0f;
                            break;
                        case KeyEvent.KEYCODE_DPAD_DOWN:
                            dy = down ? 1f : 0f;
                            break;
                        case KeyEvent.KEYCODE_DPAD_LEFT:
                            dx = down ? -1f : 0f;
                            break;
                        case KeyEvent.KEYCODE_DPAD_RIGHT:
                            dx = down ? 1f : 0f;
                            break;
                        default:
                            break;
                    }
                    l.onDpad(dx, dy);
                }
                break;
            default:
                break;
        }
    }

    // ---------------- 绘制 ----------------

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float x = mCursorX;
        float y = mCursorY;
        float s = dp(mCursorSizeDp); // 箭头尺寸（像素）

        if (mDragMode) {
            canvas.drawCircle(x, y, s * 0.9f, mDragRing);
        }

        // 电脑同款鼠标箭头（Windows 指针风格）：白底 + 黑描边，热点在箭头尖
        // 箭头几何：尖端 (0,0)，主体向右下斜
        mArrow.reset();
        mArrow.moveTo(0, 0);
        mArrow.lineTo(0, s * 0.90f);
        mArrow.lineTo(s * 0.24f, s * 0.70f);
        mArrow.lineTo(s * 0.40f, s * 1.08f);
        mArrow.lineTo(s * 0.56f, s * 0.92f);
        mArrow.lineTo(s * 0.38f, s * 0.56f);
        mArrow.lineTo(s * 0.55f, s * 0.56f);
        mArrow.close();
        canvas.save();
        canvas.translate(x, y);
        canvas.drawPath(mArrow, mFill);   // 白色填充
        canvas.drawPath(mArrow, mRing);   // 黑色描边
        canvas.restore();

        // 右下角状态文字（注入后端状态）
        if (mStatusText != null && mStatusText.length() > 0) {
            mLabel.setTextAlign(Paint.Align.RIGHT);
            canvas.drawText(mStatusText, mScreenW - dp(10), mScreenH - dp(10), mLabel);
        }
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }
}
