package com.gamepadmouse.app.core;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import com.gamepadmouse.app.MainActivity;
import com.gamepadmouse.app.R;
import com.gamepadmouse.app.access.GamepadAccessibilityService;
import com.gamepadmouse.app.inject.AccessibilityBackend;
import com.gamepadmouse.app.inject.BackendChooser;
import com.gamepadmouse.app.inject.InputBackend;
import com.gamepadmouse.app.inject.NoopBackend;
import com.gamepadmouse.app.inject.ShizukuBackend;
import com.gamepadmouse.app.util.Prefs;
import com.gamepadmouse.shizuku.ShizukuManager;

/**
 * 前台服务：创建悬浮光标、接收手柄输入、驱动注入后端。
 * 生命周期严格管理：重复启动不重复添加悬浮窗；onDestroy 清理所有资源。
 * 所有关键路径均捕获异常，防闪退。
 */
public class GamepadMouseService extends Service implements CursorOverlayView.Listener {

    private static final String TAG = "GamepadMouseService";

    private static final String CHANNEL_ID = "gamepad_mouse_fgs";
    private static final int NOTIF_ID = 1001;
    private static final long FRAME_MS = 10L; // 100Hz 光标刷新

    public static final String ACTION_START = "com.gamepadmouse.app.action.START";
    public static final String ACTION_STOP = "com.gamepadmouse.app.action.STOP";

    private static volatile GamepadMouseService sInstance;

    private WindowManager mWindowManager;
    private CursorOverlayView mOverlay;
    private boolean mOverlayAdded;
    private final Handler mHandler = new Handler(Looper.getMainLooper());

    /** 注入后端。只能在 onCreate() 里初始化：
     *  构造函数阶段 Service 的 Context 尚未 attach（为 null），
     *  任何「构造时 new 需要 Context 的对象」都会触发
     *  NullPointerException → 服务创建失败 → 点启动即闪退（日志已实锤）。 */
    private InputBackend mBackend;
    private ShizukuManager mShizukuManager;
    private ShizukuManager.StateListener mShizukuListener;

    /** 媒体键屏蔽会话：鼠标模式期间吞掉所有媒体键，防止手柄映射的媒体键控制系统音乐 */
    private MediaSession mMediaSession;

    private int mScreenW = 1080;
    private int mScreenH = 1920;
    private boolean mRunning;
    private int mOffsetRefreshCount;
    /** 左键按住状态（按住左键移动光标 = 手指滑动） */
    private boolean mLButtonHeld;
    /** 右摇杆手势滑动：上次滑动开始时间（平均 0.5s 一次） */
    private long mLastSwipeAt;
    /** 触摸注入互斥锁：手势滑动在后台线程执行，与主线程拖拽/按键注入互斥 */
    private final Object mTouchLock = new Object();
    /** 后台滑动执行器（不阻塞输入循环） */
    private java.util.concurrent.ExecutorService mSwipeExecutor;
    /** 后端实时检测计数（每 60 帧 ≈ 1 秒检测一次） */
    private int mBackendCheckCount;

    // ---- L2 智能左键状态机（短按=单击；阈值内移动/超时=长按拖动）----
    /** L2 当前按下但尚未判定（等待 单击 vs 长按/拖动） */
    private boolean mL2Held;
    /** L2 已进入长按/拖拽激活状态 */
    private boolean mL2Activated;
    /** 拖动跟手限幅：上一次触摸移动坐标（防止窗口/小窗跳变） */
    private float mLastMoveX;
    private float mLastMoveY;
    /** L2 判定定时器：到期未松手 → 进入持续长按 */
    private final Runnable mL2Timer = new Runnable() {
        @Override
        public void run() {
            try {
                synchronized (mTouchLock) {
                    if (!mL2Held || mL2Activated) return;
                    mL2Activated = true;
                    mLButtonHeld = true;
                    CursorOverlayView v = mOverlay;
                    if (v != null) {
                        doTouchDown((int) v.getScreenCursorX(), (int) v.getScreenCursorY());
                        Log.i(TAG, "L2: 超时 → 持续长按");
                    }
                }
            } catch (Throwable t) {
                Log.w(TAG, "l2 timer error: " + t);
            }
        }
    };

    /** 统一触摸按下（记录跟手起点，供限幅使用） */
    private void doTouchDown(int x, int y) {
        synchronized (mTouchLock) {
            mLastMoveX = x;
            mLastMoveY = y;
            mBackend.touchDown(x, y);
        }
    }

    /** 统一触摸移动（单帧限幅 56px，拖动窗口/小窗更稳，避免被识别为快速滑动） */
    private void doTouchMove(int x, int y) {
        synchronized (mTouchLock) {
            float mx = x;
            float my = y;
            float dx = mx - mLastMoveX;
            float dy = my - mLastMoveY;
            float dist = (float) Math.sqrt(dx * dx + dy * dy);
            if (dist > 56f) {
                mx = mLastMoveX + dx / dist * 56f;
                my = mLastMoveY + dy / dist * 56f;
            }
            mLastMoveX = mx;
            mLastMoveY = my;
            mBackend.touchMove((int) mx, (int) my);
        }
    }

    /** 统一触摸抬起 */
    private void doTouchUp() {
        synchronized (mTouchLock) {
            mBackend.touchUp();
        }
    }

    public static boolean isRunning() {
        return sInstance != null && sInstance.mRunning;
    }

    public static GamepadMouseService get() {
        return sInstance;
    }

    /** 当前生效的注入后端名称（供 UI 显示） */
    public String getBackendName() {
        return mBackend != null ? mBackend.name() : "未连接";
    }

    /** 设置里改了光标大小后调用：立即生效 */
    public void refreshCursorSize() {
        if (mOverlay != null) {
            mOverlay.refreshCursorSize();
        }
    }

    /** 把注入后端状态同步到悬浮窗右下角文字 */
    private void applyStatusText() {
        if (mOverlay != null) {
            mOverlay.setStatusText(mBackend != null ? "后端: " + mBackend.name() : "后端: 未连接");
        }
    }

    /**
     * 重新评估注入后端（供无障碍连接成功 / 主界面刷新时调用）。
     * 后台静默重连 Shizuku；notify=true 时后端切换会弹提示。
     */
    public static void recheckBackend(final boolean notify) {
        final GamepadMouseService s = sInstance;
        if (s == null || !s.mRunning) {
            return;
        }
        s.mHandler.post(() -> {
            try {
                s.tryBindShizuku();
                s.selectBackend(notify);
                s.updateNotification();
            } catch (Throwable t) {
                Log.w(TAG, "recheckBackend error: " + t);
            }
        });
    }

    @Override
    public void onCreate() {
        super.onCreate();
        sInstance = this;
        // Context 已就绪，在这里初始化需要 Context 的成员（绝不能在构造函数里做）
        mBackend = new NoopBackend(this);
        mShizukuManager = new ShizukuManager(this);
        mSwipeExecutor = java.util.concurrent.Executors.newSingleThreadExecutor();
        mShizukuListener = ready -> {
            // Shizuku 就绪/断开时，主线程重新选择后端
            mHandler.post(() -> {
                Log.i(TAG, "Shizuku state changed: " + ready);
                selectBackend(true);
            });
        };
        mShizukuManager.addListener(mShizukuListener);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if (!Settings.canDrawOverlays(this)) {
            toast("需要悬浮窗权限才能显示光标");
            openOverlaySettings();
            stopSelf();
            return START_NOT_STICKY;
        }

        // Android 12+ 前台服务启动限制：startForeground 可能抛
        // ForegroundServiceStartNotAllowedException 等异常。若不捕获，异常会走
        // 全局 CrashHandler → 进程被杀 → 表现为“点启动就退出”。
        // 捕获后降级为普通服务继续运行：功能不受影响，仅通知可能不显示。
        try {
            startForeground(NOTIF_ID, buildNotification("正在启动…"));
        } catch (Throwable t) {
            Log.w(TAG, "startForeground failed (Android12+ FGS限制): " + t);
            toast("前台服务被系统限制（" + t.getClass().getSimpleName() + "），功能仍可正常使用");
        }

        if (!mRunning) {
            mRunning = true;
            // 启动串行化：先出光标，再跑输入循环，再屏蔽媒体键，最后确定注入后端
            if (!ensureOverlay()) {
                // 悬浮窗创建失败：明确提示原因后干净退出（不是崩溃闪退）
                stopSelf();
                return START_NOT_STICKY;
            }
            applyStatusText();
            startFrameLoop();
            // 屏蔽系统媒体键响应（手柄被映射为媒体键时不再控制音乐/视频）
            initMediaSession();
            // 先同步右下角状态文字，再明确告知当前注入后端
            applyStatusText();
            // 明确告知当前注入后端；未连接时给出可操作提示
            selectBackend(true);
            toast("鼠标模式已启动：手柄输入已接管，按 SELECT 退出");
        }
        // Shizuku 绑定是异步的，不阻塞启动；就绪后经监听器自动切换后端
        tryBindShizuku();
        updateNotification();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        Log.i(TAG, "service destroyed");
        mRunning = false;
        sInstance = null;
        mHandler.removeCallbacksAndMessages(null);
        if (mSwipeExecutor != null) {
            mSwipeExecutor.shutdownNow();
            mSwipeExecutor = null;
        }
        removeOverlay();
        releaseMediaSession();
        if (mShizukuManager != null) {
            mShizukuManager.removeListener(mShizukuListener);
            mShizukuManager.unbind();
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // ---------------- 悬浮窗 ----------------

    private boolean ensureOverlay() {
        try {
            if (mOverlayAdded) {
                return true;
            }
            mWindowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            mOverlay = new CursorOverlayView(this);
            mOverlay.setListener(this);

            int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                            | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.setTitle("GamepadMouseOverlay");

            // 先用显示尺寸立即设置屏幕大小并居中，保证光标马上可见（不依赖窗口布局时序）
            DisplayMetrics dm = getResources().getDisplayMetrics();
            if (dm.widthPixels > 0 && dm.heightPixels > 0) {
                mScreenW = dm.widthPixels;
                mScreenH = dm.heightPixels;
                mOverlay.setScreenSize(mScreenW, mScreenH);
                mOverlay.centerCursor();
            }

            mWindowManager.addView(mOverlay, lp);
            mOverlayAdded = true;
            mOverlay.invalidate();

            // 布局完成后校准并确保拿到输入焦点（多次重试，覆盖部分机型时序问题）
            mOverlay.post(() -> {
                try {
                    // 坐标模型：
                    //  - 光标位置使用「窗口内坐标」（绘制与窗口一致，光标始终可见）；
                    //  - 注入时用 getScreenCursorX/Y = 窗口坐标 + 悬浮窗屏幕偏移。
                    //  这样即使 ROM 把悬浮窗放在状态栏下方（窗口不从 (0,0) 开始），
                    //  点击位置与箭头尖端也严格一致，不偏移。
                    int w = mOverlay.getWidth();
                    int h = mOverlay.getHeight();
                    if (w > 0 && h > 0) {
                        mScreenW = w;
                        mScreenH = h;
                        mOverlay.setScreenSize(w, h);
                    }
                    mOverlay.refreshScreenOffset();
                    mOverlay.centerCursor();
                    requestOverlayFocus(0);
                } catch (Throwable t) {
                    Log.w(TAG, "overlay post error: " + t);
                }
            });
            return true;
        } catch (Throwable t) {
            Log.e(TAG, "add overlay failed", t);
            toast("悬浮窗创建失败：" + t.getMessage()
                    + "（若为 vivo/OPPO 等系统，请在「设置-应用-特殊应用权限」中允许悬浮窗）");
            return false;
        }
    }

    /** 反复请求 overlay 输入焦点：焦点到位后手柄按键/摇杆才会全部进本应用（屏蔽系统控制的前提） */
    private void requestOverlayFocus(int attempt) {
        try {
            if (!mRunning || mOverlay == null) return;
            if (mOverlay.hasFocus()) return;
            mOverlay.requestFocus();
            if (attempt < 5) {
                mHandler.postDelayed(() -> requestOverlayFocus(attempt + 1), 100L);
            }
        } catch (Throwable t) {
            Log.w(TAG, "request focus error: " + t);
        }
    }

    private void removeOverlay() {
        try {
            if (mOverlayAdded && mOverlay != null && mWindowManager != null) {
                mWindowManager.removeView(mOverlay);
            }
        } catch (Throwable t) {
            Log.w(TAG, "remove overlay error: " + t);
        }
        mOverlayAdded = false;
        mOverlay = null;
    }

    // ---------------- 媒体键屏蔽 ----------------

    private void initMediaSession() {
        try {
            if (mMediaSession != null) return;
            mMediaSession = new MediaSession(this, "GamepadMouseBlocker");
            mMediaSession.setCallback(new MediaSession.Callback() {
                @Override
                public boolean onMediaButtonEvent(Intent intent) {
                    // 消费所有媒体键：屏蔽手柄被映射为媒体键时对系统音乐/视频的控制
                    return true;
                }

                @Override
                public void onPlay() {
                }

                @Override
                public void onPause() {
                }

                @Override
                public void onStop() {
                }

                @Override
                public void onSkipToNext() {
                }

                @Override
                public void onSkipToPrevious() {
                }

                @Override
                public void onSeekTo(long pos) {
                }
            });
            try {
                PlaybackState state = new PlaybackState.Builder()
                        .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE
                                | PlaybackState.ACTION_PLAY_PAUSE)
                        .setState(PlaybackState.STATE_PAUSED, 0, 1f)
                        .build();
                mMediaSession.setPlaybackState(state);
            } catch (Throwable ignored) {
            }
            mMediaSession.setActive(true);
            Log.i(TAG, "media session active (media keys blocked)");
        } catch (Throwable t) {
            Log.w(TAG, "init media session error: " + t);
        }
    }

    private void releaseMediaSession() {
        try {
            if (mMediaSession != null) {
                mMediaSession.setActive(false);
                mMediaSession.release();
                mMediaSession = null;
            }
        } catch (Throwable t) {
            Log.w(TAG, "release media session error: " + t);
        }
    }

    // ---------------- 后端选择 ----------------

    /**
     * 选择注入后端（二选一互斥，不会两个同时生效）。
     * 决策逻辑由 BackendChooser 提供（可单元测试）：
     *  Shizuku 就绪 → 只用 Shizuku（真左/右/中键）；
     *  否则无障碍已连接 → 只用无障碍（降级手势）；
     *  都没有 → Noop 占位，点击/滚动由无障碍/系统手势无法注入时给出提示。
     */
    private void selectBackend(boolean notify) {
        try {
            boolean shizukuReady = mShizukuManager != null && mShizukuManager.isReady();
            boolean a11yReady = GamepadAccessibilityService.isConnected();
            BackendChooser.Choice choice = BackendChooser.choose(shizukuReady, a11yReady);
            InputBackend next;
            switch (choice) {
                case SHIZUKU:
                    next = new ShizukuBackend(mShizukuManager);
                    break;
                case ACCESSIBILITY:
                    next = new AccessibilityBackend();
                    break;
                default:
                    next = new NoopBackend(this);
                    break;
            }
            if (mBackend != null && mBackend.getClass().equals(next.getClass())) {
                return;
            }
            mBackend = next;
            applyStatusText();
            if (notify) {
                if (next instanceof NoopBackend) {
                    toast("注入后端未连接：请启动 Shizuku 或开启无障碍注入，点击才会生效");
                } else {
                    toast("注入后端：" + mBackend.name());
                }
            }
        } catch (Throwable t) {
            Log.e(TAG, "selectBackend error", t);
            mBackend = new NoopBackend(this);
        }
    }

    private void tryBindShizuku() {
        if (mShizukuManager != null) {
            mShizukuManager.bind();
        }
    }

    // ---------------- 输入循环 ----------------

    private void startFrameLoop() {
        mHandler.removeCallbacks(mFrame);
        mHandler.post(mFrame);
    }

    private final Runnable mFrame = new Runnable() {
        @Override
        public void run() {
            if (!mRunning) return;
            try {
                CursorOverlayView v = mOverlay;
                if (v != null) {
                    // 周期性刷新悬浮窗屏幕偏移（系统栏/窗口位置可能变化）
                    if (++mOffsetRefreshCount >= 100) {
                        mOffsetRefreshCount = 0;
                        v.refreshScreenOffset();
                    }
                    float sens = Prefs.getSensitivity(GamepadMouseService.this);
                    // L2/R2 已改为鼠标左右键，速度倍率固定为 1（原加速/减速功能移除）
                    float speed = sens;

                    v.moveBy(v.getStickX() * speed, v.getStickY() * speed);

                    // 右摇杆：向摇杆方向模拟手指滑动（鼠标位置为起点）
                    //  - 滑动距离可调 3.0~5.0 cm（换算为像素）
                    //  - 平均 0.5 秒触发一次（推住不重复狂发）
                    //  - 死区可调，幅度小于死区判定为回中
                    //  - 拖动/长按中不触发滑动，避免事件打架
                    float rsx = v.getRightStickX();
                    float rsy = v.getRightStickY();
                    float dead = Prefs.getStickDeadzone(GamepadMouseService.this);
                    float mag = (float) Math.sqrt(rsx * rsx + rsy * rsy);
                    if (mag > dead && !mLButtonHeld && !v.isDragMode()) {
                        long now = SystemClock.uptimeMillis();
                        if (now - mLastSwipeAt >= 500) {
                            float dirX = rsx / mag;
                            float dirY = rsy / mag;
                            float cm = Prefs.getSwipeDistanceCm(GamepadMouseService.this);
                            float dpi = getResources().getDisplayMetrics().xdpi;
                            float distPx = cm * dpi / 2.54f;
                            final int fx = (int) v.getScreenCursorX();
                            final int fy = (int) v.getScreenCursorY();
                            final float fdx = dirX * distPx;
                            final float fdy = dirY * distPx;
                            mLastSwipeAt = now;
                            // 后台执行完整滑动序列（约 160ms），不阻塞输入循环
                            if (mSwipeExecutor != null) {
                                mSwipeExecutor.execute(() -> {
                                    synchronized (mTouchLock) {
                                        mBackend.swipe(fx, fy, fdx, fdy);
                                    }
                                });
                            }
                        }
                    }

                    // L2 判定中：0~200ms 内移动左摇杆（幅度超死区）→ 判定为按住窗口拖动
                    if (mL2Held && !mL2Activated) {
                        float stickMag = Math.abs(v.getStickX()) + Math.abs(v.getStickY());
                        if (stickMag > dead) {
                            synchronized (mTouchLock) {
                                if (mL2Held && !mL2Activated) {
                                    mL2Activated = true;
                                    mLButtonHeld = true;
                                    mHandler.removeCallbacks(mL2Timer);
                                    doTouchDown((int) v.getScreenCursorX(), (int) v.getScreenCursorY());
                                    Log.i(TAG, "L2: 0-200ms 内移动左摇杆 → 按住拖动");
                                }
                            }
                        }
                    }

                    // 按住左键 / 拖拽中：持续跟手注入触摸移动（等同手指按住窗口拖动，
                    // 单帧限幅防跳变，窗口/小窗跟手更稳）
                    if (v.isDragMode() || mLButtonHeld) {
                        doTouchMove((int) v.getScreenCursorX(), (int) v.getScreenCursorY());
                    }

                    // 实时检测注入后端：失效时自动重新选择（Shizuku / 无障碍任一可用即可）
                    if (++mBackendCheckCount >= 60) {
                        mBackendCheckCount = 0;
                        try {
                            if (mBackend == null || !mBackend.isReady()) {
                                selectBackend(false);
                            }
                        } catch (Throwable t2) {
                            Log.w(TAG, "backend check error: " + t2);
                        }
                    }
                }
            } catch (Throwable t) {
                Log.w(TAG, "frame error: " + t);
            }
            mHandler.postDelayed(this, FRAME_MS);
        }
    };

    // ---------------- 手柄按键回调 ----------------

    @Override
    public void onPrimaryClick() {
        try {
            CursorOverlayView v = mOverlay;
            InputBackend b = mBackend;
            if (v == null || b == null) return;
            b.leftClick((int) v.getScreenCursorX(), (int) v.getScreenCursorY());
        } catch (Throwable t) {
            Log.w(TAG, "click error: " + t);
        }
    }

    @Override
    public void onSecondaryClick() {
        try {
            CursorOverlayView v = mOverlay;
            InputBackend b = mBackend;
            if (v == null || b == null) return;
            b.rightClick((int) v.getScreenCursorX(), (int) v.getScreenCursorY());
        } catch (Throwable t) {
            Log.w(TAG, "right click error: " + t);
        }
    }

    @Override
    public void onMiddleClick() {
        try {
            CursorOverlayView v = mOverlay;
            InputBackend b = mBackend;
            if (v == null || b == null) return;
            b.middleClick((int) v.getScreenCursorX(), (int) v.getScreenCursorY());
        } catch (Throwable t) {
            Log.w(TAG, "middle click error: " + t);
        }
    }

    @Override
    public void onPrimaryDown() {
        // L2 左键智能判定：
        //  - 按下开始计时（阈值可调，默认 200ms），不立即注入；
        //  - 阈值内松手且未移动 → 单击左键；
        //  - 阈值内移动左摇杆 → 立即触摸按下进入拖拽（手指按住拖动）；
        //  - 超时不松手 → 持续不间断长按。
        try {
            synchronized (mTouchLock) {
                CursorOverlayView v = mOverlay;
                InputBackend b = mBackend;
                if (v == null || b == null) return;
                // 与拖拽互斥：若正在拖拽，先结束拖拽再判定
                if (v.isDragMode()) {
                    v.setDragMode(false);
                    doTouchUp();
                }
                mL2Held = true;
                mL2Activated = false;
                mHandler.removeCallbacks(mL2Timer);
                mHandler.postDelayed(mL2Timer, Prefs.getL2ClickMs(this));
            }
        } catch (Throwable t) {
            Log.w(TAG, "primary down error: " + t);
        }
    }

    @Override
    public void onPrimaryUp() {
        try {
            synchronized (mTouchLock) {
                InputBackend b = mBackend;
                if (b == null) return;
                mHandler.removeCallbacks(mL2Timer);
                if (mL2Activated) {
                    // 已进入长按/拖拽 → 抬起触摸
                    mL2Activated = false;
                    mLButtonHeld = false;
                    doTouchUp();
                } else if (mL2Held) {
                    // 阈值内松手且未移动 → 单击左键
                    CursorOverlayView v = mOverlay;
                    if (v != null) {
                        b.leftClick((int) v.getScreenCursorX(), (int) v.getScreenCursorY());
                        Log.i(TAG, "L2: 短按 → 单击");
                    }
                }
                mL2Held = false;
            }
        } catch (Throwable t) {
            Log.w(TAG, "primary up error: " + t);
        }
    }

    @Override
    public void onSecondaryDown() {
        // 右键按住（短按=点击，长按=右键长按）：鼠标 BUTTON_SECONDARY 按下
        try {
            CursorOverlayView v = mOverlay;
            InputBackend b = mBackend;
            if (v == null || b == null) return;
            synchronized (mTouchLock) {
                b.rightDown((int) v.getScreenCursorX(), (int) v.getScreenCursorY());
            }
        } catch (Throwable t) {
            Log.w(TAG, "secondary down error: " + t);
        }
    }

    @Override
    public void onSecondaryUp() {
        try {
            InputBackend b = mBackend;
            if (b == null) return;
            synchronized (mTouchLock) {
                b.rightUp();
            }
        } catch (Throwable t) {
            Log.w(TAG, "secondary up error: " + t);
        }
    }

    @Override
    public void onDragChanged(boolean down) {
        try {
            CursorOverlayView v = mOverlay;
            InputBackend b = mBackend;
            if (v == null || b == null) return;
            synchronized (mTouchLock) {
                v.setDragMode(down);
                if (down) {
                    // 取消 L2 未完成的判定（若按下中）
                    if (mL2Held) {
                        mL2Held = false;
                        mHandler.removeCallbacks(mL2Timer);
                    }
                    // 与左键按住互斥：若正按住左键，先松开再开始拖拽
                    if (mLButtonHeld) {
                        mLButtonHeld = false;
                        doTouchUp();
                    }
                    doTouchDown((int) v.getScreenCursorX(), (int) v.getScreenCursorY());
                } else {
                    doTouchUp();
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "drag error: " + t);
        }
    }

    @Override
    public void onDiscreteScroll(float amount) {
        try {
            CursorOverlayView v = mOverlay;
            InputBackend b = mBackend;
            if (v == null || b == null) return;
            // L1/R1：一次发一格（正负号表示方向）
            b.scroll((int) v.getScreenCursorX(), (int) v.getScreenCursorY(),
                    amount > 0 ? 1f : -1f);
        } catch (Throwable t) {
            Log.w(TAG, "scroll error: " + t);
        }
    }

    @Override
    public void onBoostChanged(boolean on) {
        // L2 扳机已改为鼠标左键（接口保留，不再响应）
    }

    @Override
    public void onSlowChanged(boolean on) {
        // R2 扳机已改为鼠标右键（接口保留，不再响应）
    }

    @Override
    public void onExitRequested() {
        // 退出鼠标模式：停止服务（移除悬浮窗，恢复手机正常操作）
        toast("已退出鼠标模式");
        stopSelf();
    }

    @Override
    public void onMenuRequested() {
        try {
            InputBackend b = mBackend;
            if (b != null && b.isReady()) {
                b.key(KeyEvent.KEYCODE_APP_SWITCH);
            }
        } catch (Throwable t) {
            Log.w(TAG, "menu error: " + t);
        }
    }

    @Override
    public void onBackRequested() {
        // 系统返回：注入 BACK 键（可在设置页/任意界面正常返回）
        try {
            InputBackend b = mBackend;
            if (b != null && b.isReady()) {
                b.key(KeyEvent.KEYCODE_BACK);
            }
        } catch (Throwable t) {
            Log.w(TAG, "back error: " + t);
        }
    }

    @Override
    public void onSwipeGesture(float dirX, float dirY) {
        // 自定义动作：向指定方向做手指滑动手势（距离用右摇杆滑动距离设置）
        try {
            CursorOverlayView v = mOverlay;
            InputBackend b = mBackend;
            if (v == null || b == null) return;
            float cm = Prefs.getSwipeDistanceCm(this);
            float dpi = getResources().getDisplayMetrics().xdpi;
            float dist = cm * dpi / 2.54f;
            final int fx = (int) v.getScreenCursorX();
            final int fy = (int) v.getScreenCursorY();
            final float fdx = dirX * dist;
            final float fdy = dirY * dist;
            if (mSwipeExecutor != null) {
                mSwipeExecutor.execute(() -> {
                    synchronized (mTouchLock) {
                        mBackend.swipe(fx, fy, fdx, fdy);
                    }
                });
            }
        } catch (Throwable t) {
            Log.w(TAG, "swipe gesture error: " + t);
        }
    }

    @Override
    public void onToggleStick() {
        CursorOverlayView v = mOverlay;
        InputBackend b = mBackend;
        if (v == null || b == null) return;
        synchronized (mTouchLock) {
            boolean next = !v.isDragMode();
            v.setDragMode(next);
            if (next) {
                doTouchDown((int) v.getScreenCursorX(), (int) v.getScreenCursorY());
            } else {
                doTouchUp();
            }
        }
    }

    @Override
    public void onDpad(float dx, float dy) {
        try {
            if (mOverlay != null) {
                mOverlay.moveDpad(dx * 2.5f, dy * 2.5f);
            }
        } catch (Throwable t) {
            Log.w(TAG, "dpad error: " + t);
        }
    }

    // ---------------- 通知 ----------------

    private void updateNotification() {
        try {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                nm.notify(NOTIF_ID, buildNotification("运行中 · 注入：" + getBackendName()
                        + " · 手柄已接管（SELECT 退出）"));
            }
        } catch (Throwable t) {
            Log.w(TAG, "update notif error: " + t);
        }
    }

    private Notification buildNotification(String text) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID, "手柄鼠标", NotificationManager.IMPORTANCE_LOW);
                channel.setDescription("手柄鼠标前台服务");
                NotificationManager nm = getSystemService(NotificationManager.class);
                if (nm != null) nm.createNotificationChannel(channel);
            }
            Intent open = new Intent(this, MainActivity.class);
            PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Intent stop = new Intent(this, GamepadMouseService.class).setAction(ACTION_STOP);
            PendingIntent stopPi = PendingIntent.getService(this, 1, stop,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Notification.Builder nb = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? new Notification.Builder(this, CHANNEL_ID)
                    : new Notification.Builder(this);
            nb.setSmallIcon(R.drawable.ic_notification)
                    .setContentTitle("手柄鼠标")
                    .setContentText(text)
                    .setContentIntent(pi)
                    .setOngoing(true)
                    .setOnlyAlertOnce(true);
            nb.addAction(0, "停止", stopPi);
            return nb.build();
        } catch (Throwable t) {
            Log.w(TAG, "notif build error: " + t);
            return new Notification.Builder(this).build();
        }
    }

    // ---------------- 工具 ----------------

    private void toast(String msg) {
        try {
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        } catch (Throwable ignored) {
        }
    }

    private void openOverlaySettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    android.net.Uri.parse("package:" + getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Throwable t) {
            Log.w(TAG, "open overlay settings error: " + t);
        }
    }
}
