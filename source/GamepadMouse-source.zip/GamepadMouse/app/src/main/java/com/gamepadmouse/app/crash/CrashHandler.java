package com.gamepadmouse.app.crash;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 全局未捕获异常处理器 —— 防闪退的最后一道防线。
 * 作用：
 *  1. 把所有异常（含子线程）写入应用私有目录 crash.log，便于排查；
 *  2. 弹 Toast 提示用户；
 *  3. 重新拉起主界面，避免应用“死掉后无响应”。
 * 注意：真正的“不闪退”靠代码里的防御性检查，这里只兜底。
 */
public class CrashHandler implements Thread.UncaughtExceptionHandler {

    private static final String TAG = "CrashHandler";
    private static final String CRASH_FILE = "crash.log";
    private static final int MAX_CRASH_SIZE = 256 * 1024;

    private final Context mContext;
    private final Thread.UncaughtExceptionHandler mDefaultHandler;
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    private CrashHandler(Context context) {
        mContext = context.getApplicationContext();
        mDefaultHandler = Thread.getDefaultUncaughtExceptionHandler();
    }

    public static void install(Context context) {
        Thread.setDefaultUncaughtExceptionHandler(new CrashHandler(context));
    }

    @Override
    public void uncaughtException(final Thread thread, final Throwable throwable) {
        try {
            String log = buildLog(thread, throwable);
            writeLog(log);

            mMainHandler.post(() -> {
                try {
                    Toast.makeText(mContext, "检测到异常，已记录并尝试恢复", Toast.LENGTH_LONG).show();
                } catch (Throwable ignored) {
                }
            });
            // 短暂等待 Toast 展示后，重新拉起主界面（新进程）
            mMainHandler.postDelayed(this::relaunchApp, 800);
        } catch (Throwable t) {
            Log.e(TAG, "crash handler failed", t);
        }
        // 交给系统默认处理器收尾（打印到 logcat）
        if (mDefaultHandler != null) {
            mDefaultHandler.uncaughtException(thread, throwable);
        } else {
            Process.killProcess(Process.myPid());
        }
    }

    private String buildLog(Thread thread, Throwable throwable) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        pw.println("==== " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()) + " ====");
        pw.println("Thread: " + thread.getName() + " (id=" + thread.getId() + ")");
        pw.println("Package: " + mContext.getPackageName());
        pw.println("Sdk: " + android.os.Build.VERSION.SDK_INT + " / " + android.os.Build.VERSION.RELEASE
                + " / " + android.os.Build.MODEL);
        throwable.printStackTrace(pw);
        pw.println();
        pw.flush();
        return sw.toString();
    }

    private void writeLog(String log) {
        try {
            File file = new File(mContext.getFilesDir(), CRASH_FILE);
            boolean append = file.exists() && file.length() < MAX_CRASH_SIZE;
            try (FileOutputStream fos = new FileOutputStream(file, append)) {
                fos.write(log.getBytes("UTF-8"));
            }
        } catch (Throwable t) {
            Log.e(TAG, "write crash log failed", t);
        }
    }

    private void relaunchApp() {
        try {
            Intent intent = mContext.getPackageManager().getLaunchIntentForPackage(mContext.getPackageName());
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                mContext.startActivity(intent);
            }
        } catch (Throwable t) {
            Log.e(TAG, "relaunch failed", t);
        }
        Process.killProcess(Process.myPid());
        System.exit(1);
    }

    /** 读取崩溃日志（供 UI 展示） */
    public static String readCrashLog(Context context) {
        try {
            File file = new File(context.getFilesDir(), CRASH_FILE);
            if (!file.exists()) return null;
            byte[] data = new byte[(int) Math.min(file.length(), MAX_CRASH_SIZE)];
            try (java.io.FileInputStream fis = new java.io.FileInputStream(file)) {
                int read = fis.read(data);
                if (read <= 0) return null;
                return new String(data, 0, read, "UTF-8");
            }
        } catch (Throwable t) {
            return null;
        }
    }

    public static boolean clearCrashLog(Context context) {
        try {
            File file = new File(context.getFilesDir(), CRASH_FILE);
            return file.exists() && file.delete();
        } catch (Throwable t) {
            return false;
        }
    }
}
