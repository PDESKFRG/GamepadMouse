package com.gamepadmouse.app.inject;

import android.view.KeyEvent;

import com.gamepadmouse.app.access.GamepadAccessibilityService;

/**
 * 无障碍注入后端（无 Shizuku 时的降级方案）。
 */
public class AccessibilityBackend implements InputBackend {

    // 无障碍滑动节流：至少间隔 200ms，且攒够约 2 格才滑动一次
    private long mLastSwipeAt;
    private float mPendingScroll;

    @Override
    public String name() {
        return "无障碍";
    }

    @Override
    public boolean isReady() {
        return GamepadAccessibilityService.isConnected();
    }

    @Override
    public boolean leftClick(int x, int y) {
        return GamepadAccessibilityService.tap(x, y);
    }

    @Override
    public boolean rightClick(int x, int y) {
        return GamepadAccessibilityService.longPress(x, y);
    }

    @Override
    public boolean middleClick(int x, int y) {
        return GamepadAccessibilityService.doubleFingerTap(x, y);
    }

    @Override
    public boolean scroll(int x, int y, float amount) {
        mPendingScroll += amount;
        long now = System.currentTimeMillis();
        if (Math.abs(mPendingScroll) >= 2f && now - mLastSwipeAt >= 200) {
            boolean ok = GamepadAccessibilityService.swipe(x, y, mPendingScroll);
            mPendingScroll = 0f;
            mLastSwipeAt = now;
            return ok;
        }
        return false;
    }

    @Override
    public boolean touchDown(int x, int y) {
        // 无障碍不支持按住拖拽，降级为一次长按开始
        return GamepadAccessibilityService.longPress(x, y);
    }

    @Override
    public boolean touchMove(int x, int y) {
        return false;
    }

    @Override
    public boolean touchUp() {
        return false;
    }

    @Override
    public boolean rightDown(int x, int y) {
        // 无障碍无真实右键按住，降级为长按（相当于右键菜单）
        return GamepadAccessibilityService.longPress(x, y);
    }

    @Override
    public boolean rightUp() {
        return false;
    }

    @Override
    public boolean swipe(int fromX, int fromY, float dx, float dy) {
        return GamepadAccessibilityService.swipeVector(fromX, fromY, dx, dy);
    }

    @Override
    public boolean key(int keyCode) {
        // 无障碍不支持系统按键注入，忽略（START 最近任务在无障碍模式下不可用）
        if (keyCode == KeyEvent.KEYCODE_APP_SWITCH) {
            return false;
        }
        return false;
    }
}
