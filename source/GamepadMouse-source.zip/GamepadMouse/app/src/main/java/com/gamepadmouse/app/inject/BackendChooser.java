package com.gamepadmouse.app.inject;

/**
 * 注入后端选择决策（纯逻辑，可单元测试）。
 * 强制“二选一”互斥：Shizuku 可用优先，否则无障碍，都没有则为 NONE。
 */
public final class BackendChooser {

    public enum Choice {
        SHIZUKU, ACCESSIBILITY, NONE
    }

    private BackendChooser() {
    }

    /** 互斥选择：两个后端不会同时生效。 */
    public static Choice choose(boolean shizukuReady, boolean accessibilityReady) {
        if (shizukuReady) return Choice.SHIZUKU;
        if (accessibilityReady) return Choice.ACCESSIBILITY;
        return Choice.NONE;
    }
}
