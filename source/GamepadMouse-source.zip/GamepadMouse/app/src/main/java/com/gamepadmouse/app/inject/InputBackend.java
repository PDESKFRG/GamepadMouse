package com.gamepadmouse.app.inject;

/**
 * 输入注入后端统一接口。
 * 两个实现：
 *  - ShizukuBackend：通过 Shizuku（shell 权限）注入真实鼠标/触摸事件，支持左/右/中键，推荐；
 *  - AccessibilityBackend：通过无障碍手势注入，无需 Shizuku，仅支持基础点击/长按/滑动。
 */
public interface InputBackend {

    /** 后端名称，用于状态展示 */
    String name();

    /** 后端是否已就绪可用 */
    boolean isReady();

    /** 左键单击 */
    boolean leftClick(int x, int y);

    /** 右键单击 */
    boolean rightClick(int x, int y);

    /** 中键单击 */
    boolean middleClick(int x, int y);

    /** 滚轮滚动：amount 正数向下，负数向上 */
    boolean scroll(int x, int y, float amount);

    /** 触摸按下（拖拽开始 / 左键按住） */
    boolean touchDown(int x, int y);

    /** 触摸移动（拖拽中） */
    boolean touchMove(int x, int y);

    /** 触摸抬起（拖拽结束 / 左键松开） */
    boolean touchUp();

    /** 右键按住（鼠标 BUTTON_SECONDARY 按下，长按右键） */
    boolean rightDown(int x, int y);

    /** 右键松开（BUTTON_SECONDARY 抬起） */
    boolean rightUp();

    /** 手指滑动手势：从 (fromX, fromY) 沿 (dx,dy) 方向自然滑动（右摇杆手势） */
    boolean swipe(int fromX, int fromY, float dx, float dy);

    /** 注入系统按键 */
    boolean key(int keyCode);
}
