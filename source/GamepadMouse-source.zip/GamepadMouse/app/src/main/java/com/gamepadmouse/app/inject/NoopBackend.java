package com.gamepadmouse.app.inject;

import android.content.Context;
import android.widget.Toast;

/**
 * 无注入后端：当 Shizuku 与无障碍均不可用时兜底，只提示用户开启权限。
 * 不会崩溃，任何操作都安全返回 false。
 */
public class NoopBackend implements InputBackend {

    private final Context mContext;
    private long mLastToastAt;

    /**
     * 防御式构造：context 可能为 null（例如被误用在 Service 构造阶段）。
     * 这里不直接解引用，后续使用处判空，保证任何情况下都不抛 NPE。
     */
    public NoopBackend(Context context) {
        mContext = context == null ? null : context.getApplicationContext();
    }

    @Override
    public String name() {
        return "未连接";
    }

    @Override
    public boolean isReady() {
        return false;
    }

    @Override
    public boolean leftClick(int x, int y) {
        hint();
        return false;
    }

    @Override
    public boolean rightClick(int x, int y) {
        hint();
        return false;
    }

    @Override
    public boolean middleClick(int x, int y) {
        hint();
        return false;
    }

    @Override
    public boolean scroll(int x, int y, float amount) {
        return false; // 滚动不弹提示，避免骚扰
    }

    @Override
    public boolean touchDown(int x, int y) {
        hint();
        return false;
    }

    @Override
    public boolean touchMove(int x, int y) {
        return false;
    }

    @Override
    public boolean touchUp() {
        return false;
    }

    @Override
    public boolean rightDown(int x, int y) {
        hint();
        return false;
    }

    @Override
    public boolean rightUp() {
        return false;
    }

    @Override
    public boolean swipe(int fromX, int fromY, float dx, float dy) {
        hint();
        return false;
    }

    @Override
    public boolean key(int keyCode) {
        return false;
    }

    private void hint() {
        long now = System.currentTimeMillis();
        if (now - mLastToastAt < 3000) return; // 3 秒内只提示一次，防刷屏
        mLastToastAt = now;
        try {
            if (mContext != null) {
                Toast.makeText(mContext, "未连接注入后端：请开启 Shizuku 或无障碍权限", Toast.LENGTH_SHORT).show();
            }
        } catch (Throwable ignored) {
        }
    }
}
