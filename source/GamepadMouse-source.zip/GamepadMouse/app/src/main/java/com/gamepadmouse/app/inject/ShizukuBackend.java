package com.gamepadmouse.app.inject;

import android.os.RemoteException;
import android.util.Log;

import com.gamepadmouse.input.IInputInjector;
import com.gamepadmouse.shizuku.ShizukuManager;

/**
 * Shizuku 注入后端：把光标操作转发给运行在 Shizuku 进程中的 ShellInputService。
 * 所有 IPC 调用都做异常防护：RemoteException/DeadObject/Security 等一律捕获并返回 false。
 */
public class ShizukuBackend implements InputBackend {

    private static final String TAG = "ShizukuBackend";

    private final ShizukuManager mManager;

    public ShizukuBackend(ShizukuManager manager) {
        mManager = manager;
    }

    @Override
    public String name() {
        return "Shizuku";
    }

    @Override
    public boolean isReady() {
        return mManager != null && mManager.isReady();
    }

    @Override
    public boolean leftClick(int x, int y) {
        return call(injector -> injector.click(x, y));
    }

    @Override
    public boolean rightClick(int x, int y) {
        return call(injector -> injector.rightClick(x, y));
    }

    @Override
    public boolean middleClick(int x, int y) {
        return call(injector -> injector.middleClick(x, y));
    }

    @Override
    public boolean scroll(int x, int y, float amount) {
        return call(injector -> injector.scroll(x, y, amount));
    }

    @Override
    public boolean touchDown(int x, int y) {
        return call(injector -> injector.touchDown(x, y));
    }

    @Override
    public boolean touchMove(int x, int y) {
        return call(injector -> injector.touchMove(x, y));
    }

    @Override
    public boolean touchUp() {
        return call(IInputInjector::touchUp);
    }

    @Override
    public boolean rightDown(int x, int y) {
        return call(injector -> injector.rightDown(x, y));
    }

    @Override
    public boolean rightUp() {
        return call(IInputInjector::rightUp);
    }

    @Override
    public boolean swipe(int fromX, int fromY, float dx, float dy) {
        // 触摸滑动序列：按下 → 分步移动（先加速后减速的自然曲线）→ 抬起
        IInputInjector injector = mManager != null ? mManager.getInjector() : null;
        if (injector == null) return false;
        try {
            injector.touchDown(fromX, fromY);
            int steps = 20;
            for (int i = 1; i <= steps; i++) {
                float t = i / (float) steps;
                float ease = t < 0.5f ? 2f * t * t : (float) (1 - Math.pow(-2 * t + 2, 2) / 2);
                int x = (int) (fromX + dx * ease);
                int y = (int) (fromY + dy * ease);
                injector.touchMove(x, y);
                try {
                    Thread.sleep(8);
                } catch (InterruptedException ignored) {
                }
            }
            injector.touchUp();
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "swipe failed: " + t);
            try {
                injector.touchUp();
            } catch (Throwable ignored) {
            }
            return false;
        }
    }

    @Override
    public boolean key(int keyCode) {
        return call(injector -> injector.key(keyCode));
    }

    private interface Call {
        void run(IInputInjector injector) throws RemoteException;
    }

    private boolean call(Call call) {
        IInputInjector injector = mManager != null ? mManager.getInjector() : null;
        if (injector == null) {
            return false;
        }
        try {
            call.run(injector);
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "IPC failed: " + t);
            return false;
        }
    }
}
