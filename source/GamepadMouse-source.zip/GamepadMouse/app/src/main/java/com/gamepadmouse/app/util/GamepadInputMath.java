package com.gamepadmouse.app.util;

/**
 * 手柄输入的纯数学逻辑（无 Android 依赖，可单元测试）。
 * 轴归一化、钳制、右摇杆轴对自动选择。
 */
public final class GamepadInputMath {

    /** 摇杆死区：小于该值的输入视为回中 */
    public static final float DEADZONE = 0.12f;

    private GamepadInputMath() {
    }

    /**
     * 摇杆轴归一化：死区归零 + 幂曲线整形（轻推更平滑）。
     * 输入范围 [-1,1]（超界钳制），输出范围 [-1,1]。
     */
    public static float normalizeAxis(float raw, float deadzone) {
        if (raw > 1f) raw = 1f;
        else if (raw < -1f) raw = -1f;
        float abs = Math.abs(raw);
        if (abs < deadzone) return 0f;
        float t = (abs - deadzone) / (1f - deadzone);
        t = (float) Math.pow(Math.min(1f, t), 1.6f);
        return raw > 0 ? t : -t;
    }

    public static float normalizeAxis(float raw) {
        return normalizeAxis(raw, DEADZONE);
    }

    public static float clamp01(float v) {
        return Math.max(0f, Math.min(1f, v));
    }

    public static int clampInt(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    /**
     * 右摇杆轴对自动选择：兼容两套映射。
     *  - 索尼/微软布局：AXIS_RX / AXIS_RY
     *  - 国产/部分蓝牙手柄：AXIS_Z(右X) / AXIS_RZ(右Y)
     * 用幅值比较选出实际有信号的那一组，避免“声明了 RX/RY 但实际用 Z/RZ”的手柄失效。
     *
     * @return [x, y] 长度 2 的数组
     */
    public static float[] chooseRightStick(float rx, float ry, float z, float rz) {
        float g1 = Math.abs(rx) + Math.abs(ry);
        float g2 = Math.abs(z) + Math.abs(rz);
        if (g2 > g1) {
            return new float[]{z, rz};
        }
        return new float[]{rx, ry};
    }
}
