package com.gamepadmouse.app.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.KeyEvent;

import org.json.JSONObject;

/**
 * 设置存储。所有数值都有安全默认值，非法输入自动回退。
 */
public class Prefs {

    private static final String NAME = "gamepad_mouse_prefs";

    public static final String KEY_SENSITIVITY = "sensitivity";         // 光标速度 2..20
    public static final String KEY_SCROLL_SENS = "scroll_sensitivity";  // 右摇杆滚动距离 1..20
    public static final String KEY_CURSOR_SIZE = "cursor_size";         // 光标大小 10..56 dp
    public static final String KEY_INVERT_Y = "invert_y";
    public static final String KEY_SWAP_STICKS = "swap_sticks";
    public static final String KEY_BG_LIMIT_HINT_SHOWN = "bg_limit_hint_shown"; // OriginOS 后台限制提示只弹一次
    public static final String KEY_BUTTON_MAP = "button_map";           // 按键自定义映射（JSON）
    public static final String KEY_SWIPE_DISTANCE = "swipe_distance_cm"; // 右摇杆滑动距离 3.0..5.0 cm
    public static final String KEY_STICK_DEADZONE = "stick_deadzone";    // 摇杆死区 0.05..0.30
    public static final String KEY_L2_CLICK_MS = "l2_click_ms";          // L2 单击判定阈值 50..500 ms

    // 按键动作（存储值）
    public static final int ACTION_NONE = 0;
    public static final int ACTION_LEFT_CLICK = 1;    // 左键单击
    public static final int ACTION_RIGHT_CLICK = 2;   // 右键单击
    public static final int ACTION_MIDDLE_CLICK = 3;  // 中键单击
    public static final int ACTION_LEFT_HOLD = 4;     // 左键智能：短按=单击，超时/移动=长按拖动
    public static final int ACTION_RIGHT_HOLD = 5;    // 右键按住（短按=点击，长按=长按）
    public static final int ACTION_SCROLL_UP = 6;     // 滚轮上
    public static final int ACTION_SCROLL_DOWN = 7;   // 滚轮下
    public static final int ACTION_DRAG_TOGGLE = 8;   // 拖拽切换
    public static final int ACTION_HOLD_DRAG = 9;     // 按住拖拽（按下开始，松开结束）
    public static final int ACTION_EXIT = 10;         // 退出鼠标模式
    public static final int ACTION_RECENTS = 11;      // 最近任务
    public static final int ACTION_BACK = 12;         // 系统返回
    public static final int ACTION_SWIPE_UP = 13;     // 手指上滑手势
    public static final int ACTION_SWIPE_DOWN = 14;   // 手指下滑手势
    public static final int ACTION_SWIPE_LEFT = 15;   // 手指左滑手势
    public static final int ACTION_SWIPE_RIGHT = 16;  // 手指右滑手势
    public static final int ACTION_DPAD = 17;         // 十字键微调（默认行为）

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    public static int getSensitivity(Context c) {
        int v = prefs(c).getInt(KEY_SENSITIVITY, 8);
        return clampInt(v, 2, 20);
    }

    public static void setSensitivity(Context c, int v) {
        prefs(c).edit().putInt(KEY_SENSITIVITY, clampInt(v, 2, 20)).apply();
    }

    public static int getScrollSensitivity(Context c) {
        int v = prefs(c).getInt(KEY_SCROLL_SENS, 6);
        return clampInt(v, 1, 20);
    }

    public static void setScrollSensitivity(Context c, int v) {
        prefs(c).edit().putInt(KEY_SCROLL_SENS, clampInt(v, 1, 20)).apply();
    }

    /** 右摇杆滑动距离（cm，3.0..5.0，默认 4.0） */
    public static float getSwipeDistanceCm(Context c) {
        return clampFloat(prefs(c).getFloat(KEY_SWIPE_DISTANCE, 4.0f), 3.0f, 5.0f);
    }

    public static void setSwipeDistanceCm(Context c, float v) {
        prefs(c).edit().putFloat(KEY_SWIPE_DISTANCE, clampFloat(v, 3.0f, 5.0f)).apply();
    }

    /** 摇杆死区（0.05..0.30，默认 0.12） */
    public static float getStickDeadzone(Context c) {
        return clampFloat(prefs(c).getFloat(KEY_STICK_DEADZONE, 0.12f), 0.05f, 0.30f);
    }

    public static void setStickDeadzone(Context c, float v) {
        prefs(c).edit().putFloat(KEY_STICK_DEADZONE, clampFloat(v, 0.05f, 0.30f)).apply();
    }

    private static float clampFloat(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    /** L2 单击判定阈值（ms，50..500，默认 200）：按下后该时间内松手且未移动=单击，否则进入长按/拖动 */
    public static int getL2ClickMs(Context c) {
        return clampInt(prefs(c).getInt(KEY_L2_CLICK_MS, 200), 50, 500);
    }

    public static void setL2ClickMs(Context c, int v) {
        prefs(c).edit().putInt(KEY_L2_CLICK_MS, clampInt(v, 50, 500)).apply();
    }

    // ---------------- 按键自定义映射 ----------------

    /** 可自定义动作的按键（keyCode → 显示名） */
    public static final int[] MAPPABLE_KEYS = {
            KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_X,
            KeyEvent.KEYCODE_BUTTON_Y, KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_BUTTON_R1,
            KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_BUTTON_R2,
            KeyEvent.KEYCODE_BUTTON_SELECT, KeyEvent.KEYCODE_BUTTON_START,
            KeyEvent.KEYCODE_BUTTON_THUMBL,
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT
    };
    public static final String[] MAPPABLE_KEY_NAMES = {
            "A", "B", "X", "Y", "L1", "R1", "L2", "R2", "SELECT", "START",
            "左摇杆按下", "十字键上", "十字键下", "十字键左", "十字键右"
    };

    /** 默认映射：按键 keyCode → 动作 */
    private static int defaultAction(int keyCode) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BUTTON_A:
                return ACTION_LEFT_CLICK;
            case KeyEvent.KEYCODE_BUTTON_B:
                return ACTION_RIGHT_CLICK;
            case KeyEvent.KEYCODE_BUTTON_X:
                return ACTION_MIDDLE_CLICK;
            case KeyEvent.KEYCODE_BUTTON_Y:
                return ACTION_HOLD_DRAG;
            case KeyEvent.KEYCODE_BUTTON_L1:
                return ACTION_SCROLL_UP;
            case KeyEvent.KEYCODE_BUTTON_R1:
                return ACTION_SCROLL_DOWN;
            case KeyEvent.KEYCODE_BUTTON_L2:
                return ACTION_LEFT_HOLD;   // 智能左键：短按=单击，200ms 内移动/超时=长按拖动
            case KeyEvent.KEYCODE_BUTTON_R2:
                return ACTION_RIGHT_HOLD;
            case KeyEvent.KEYCODE_BUTTON_SELECT:
                return ACTION_EXIT;
            case KeyEvent.KEYCODE_BUTTON_START:
                return ACTION_RECENTS;
            case KeyEvent.KEYCODE_BUTTON_THUMBL:
                return ACTION_DRAG_TOGGLE;
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                return ACTION_DPAD;   // 十字键微调
            default:
                return ACTION_NONE;
        }
    }

    public static int getButtonAction(Context c, int keyCode) {
        try {
            String raw = prefs(c).getString(KEY_BUTTON_MAP, "");
            if (!raw.isEmpty()) {
                JSONObject map = new JSONObject(raw);
                if (map.has(String.valueOf(keyCode))) {
                    return clampInt(map.getInt(String.valueOf(keyCode)), 0, 17);
                }
            }
        } catch (Throwable ignored) {
        }
        return defaultAction(keyCode);
    }

    public static void setButtonAction(Context c, int keyCode, int action) {
        try {
            JSONObject map;
            String raw = prefs(c).getString(KEY_BUTTON_MAP, "");
            map = raw.isEmpty() ? new JSONObject() : new JSONObject(raw);
            map.put(String.valueOf(keyCode), action);
            prefs(c).edit().putString(KEY_BUTTON_MAP, map.toString()).apply();
        } catch (Throwable ignored) {
        }
    }

    public static void resetButtonActions(Context c) {
        prefs(c).edit().remove(KEY_BUTTON_MAP).apply();
    }

    /** 光标大小（dp），默认 22，范围 10..56 */
    public static int getCursorSize(Context c) {
        return clampInt(prefs(c).getInt(KEY_CURSOR_SIZE, 22), 10, 56);
    }

    public static void setCursorSize(Context c, int v) {
        prefs(c).edit().putInt(KEY_CURSOR_SIZE, clampInt(v, 10, 56)).apply();
    }

    public static boolean getInvertY(Context c) {
        return prefs(c).getBoolean(KEY_INVERT_Y, false);
    }

    public static void setInvertY(Context c, boolean v) {
        prefs(c).edit().putBoolean(KEY_INVERT_Y, v).apply();
    }

    public static boolean getSwapSticks(Context c) {
        return prefs(c).getBoolean(KEY_SWAP_STICKS, false);
    }

    public static void setSwapSticks(Context c, boolean v) {
        prefs(c).edit().putBoolean(KEY_SWAP_STICKS, v).apply();
    }

    public static boolean getBgLimitHintShown(Context c) {
        return prefs(c).getBoolean(KEY_BG_LIMIT_HINT_SHOWN, false);
    }

    public static void setBgLimitHintShown(Context c, boolean v) {
        prefs(c).edit().putBoolean(KEY_BG_LIMIT_HINT_SHOWN, v).apply();
    }

    private static int clampInt(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }
}
