package com.gamepadmouse.shizuku;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import android.os.SystemClock;
import android.util.Log;
import android.view.InputDevice;
import android.view.InputEvent;
import android.view.KeyEvent;
import android.view.MotionEvent;

import com.gamepadmouse.input.IInputInjector;

import java.lang.reflect.Method;

/**
 * 输入注入服务 —— 由 Shizuku 加载到其进程（shell 权限）中运行。
 * 通过反射调用隐藏 API InputManager.injectInputEvent 注入真实输入事件：
 *  - 左键：SOURCE_TOUCHSCREEN 的 DOWN/UP；
 *  - 右键：SOURCE_MOUSE + BUTTON_SECONDARY；
 *  - 中键：SOURCE_MOUSE + BUTTON_TERTIARY；
 *  - 滚轮：SOURCE_MOUSE + ACTION_SCROLL + AXIS_VSCROLL；
 *  - 拖拽：触摸 DOWN/MOVE/UP；
 *  - 按键：KeyEvent DOWN/UP。
 * 所有注入均包裹异常处理，失败只记日志，绝不崩溃。
 */
public class ShellInputService extends Service {

    private static final String TAG = "ShellInputService";
    private static final int INJECT_ASYNC = 2;

    private static volatile Object sInputManager;
    private static volatile Method sInjectMethod;

    static {
        initReflection();
    }

    private static void initReflection() {
        try {
            Class<?> cls = Class.forName("android.hardware.input.InputManager");
            Method getInstance = cls.getMethod("getInstance");
            sInputManager = getInstance.invoke(null);
            sInjectMethod = cls.getMethod("injectInputEvent", InputEvent.class, int.class);
            sInjectMethod.setAccessible(true);
            Log.i(TAG, "InputManager reflection ok");
        } catch (Throwable t) {
            sInputManager = null;
            sInjectMethod = null;
            Log.e(TAG, "InputManager reflection failed: " + t);
        }
    }

    private final IInputInjector.Stub mStub = new IInputInjector.Stub() {

        @Override
        public void click(int x, int y) {
            injectClick(x, y);
        }

        @Override
        public void rightClick(int x, int y) {
            injectMouseClick(x, y, MotionEvent.BUTTON_SECONDARY);
        }

        @Override
        public void middleClick(int x, int y) {
            injectMouseClick(x, y, MotionEvent.BUTTON_TERTIARY);
        }

        @Override
        public void movePointer(int x, int y) {
            injectHover(x, y);
        }

        @Override
        public void scroll(int x, int y, float amount) {
            injectScroll(x, y, amount);
        }

        @Override
        public void touchDown(int x, int y) {
            injectTouch(MotionEvent.ACTION_DOWN, x, y);
        }

        @Override
        public void touchMove(int x, int y) {
            injectTouch(MotionEvent.ACTION_MOVE, x, y);
        }

        @Override
        public void touchUp() {
            injectTouch(MotionEvent.ACTION_UP, -1, -1);
        }

        @Override
        public void rightDown(int x, int y) {
            inject(newMouse(MotionEvent.ACTION_DOWN, MotionEvent.BUTTON_SECONDARY, x, y));
        }

        @Override
        public void rightUp() {
            inject(newMouse(MotionEvent.ACTION_UP, MotionEvent.BUTTON_SECONDARY, 0, 0));
        }

        @Override
        public void key(int keyCode) throws RemoteException {
            injectKey(keyCode);
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return mStub;
    }

    // ---------- 事件构造与注入 ----------

    private static void inject(InputEvent event) {
        Method m = sInjectMethod;
        Object im = sInputManager;
        if (m == null || im == null) {
            Log.w(TAG, "inject skipped: InputManager not ready");
            return;
        }
        try {
            m.invoke(im, event, INJECT_ASYNC);
        } catch (Throwable t) {
            Log.e(TAG, "inject failed: " + t);
        }
    }

    private static MotionEvent newTouch(int action, int x, int y) {
        long now = SystemClock.uptimeMillis();
        MotionEvent ev;
        if (action == MotionEvent.ACTION_UP) {
            ev = MotionEvent.obtain(now, now, action, 0, 0, 0);
        } else {
            ev = MotionEvent.obtain(now, now, action, x, y, 0);
        }
        ev.setSource(InputDevice.SOURCE_TOUCHSCREEN);
        return ev;
    }

    private static MotionEvent newMouse(int action, int buttonState, int x, int y) {
        long now = SystemClock.uptimeMillis();
        MotionEvent ev = MotionEvent.obtain(now, now, action, x, y, 0);
        ev.setSource(InputDevice.SOURCE_MOUSE);
        // setButtonState / setActionButton 在部分系统版本为隐藏 API，统一用反射设置
        try {
            MotionEvent.class.getMethod("setButtonState", int.class).invoke(ev, buttonState);
        } catch (Throwable ignored) {
        }
        try {
            MotionEvent.class.getMethod("setActionButton", int.class).invoke(ev, buttonState);
        } catch (Throwable ignored) {
        }
        return ev;
    }

    private static void injectClick(int x, int y) {
        inject(newTouch(MotionEvent.ACTION_DOWN, x, y));
        SystemClock.sleep(20);
        inject(newTouch(MotionEvent.ACTION_UP, x, y));
    }

    private static void injectMouseClick(int x, int y, int button) {
        inject(newMouse(MotionEvent.ACTION_DOWN, button, x, y));
        SystemClock.sleep(20);
        inject(newMouse(MotionEvent.ACTION_UP, button, x, y));
    }

    private static void injectHover(int x, int y) {
        long now = SystemClock.uptimeMillis();
        MotionEvent ev = MotionEvent.obtain(now, now, MotionEvent.ACTION_HOVER_MOVE, x, y, 0);
        ev.setSource(InputDevice.SOURCE_MOUSE);
        inject(ev);
    }

    private static void injectScroll(int x, int y, float amount) {
        long now = SystemClock.uptimeMillis();
        MotionEvent ev = MotionEvent.obtain(now, now, MotionEvent.ACTION_SCROLL, x, y, 0);
        ev.setSource(InputDevice.SOURCE_MOUSE);
        try {
            // setAxisValue 在 android.jar 中为隐藏方法，使用反射设置垂直滚轮
            MotionEvent.class.getMethod("setAxisValue", int.class, float.class)
                    .invoke(ev, MotionEvent.AXIS_VSCROLL, amount);
        } catch (Throwable ignored) {
        }
        inject(ev);
    }

    private static void injectTouch(int action, int x, int y) {
        long now = SystemClock.uptimeMillis();
        MotionEvent ev;
        if (action == MotionEvent.ACTION_UP) {
            ev = MotionEvent.obtain(now, now, action, 0, 0, 0);
        } else {
            ev = MotionEvent.obtain(now, now, action, x, y, 0);
        }
        ev.setSource(InputDevice.SOURCE_TOUCHSCREEN);
        inject(ev);
    }

    private static void injectKey(int keyCode) {
        long now = SystemClock.uptimeMillis();
        KeyEvent down = new KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0);
        KeyEvent up = new KeyEvent(now, now + 30, KeyEvent.ACTION_UP, keyCode, 0);
        inject(down);
        inject(up);
    }
}
