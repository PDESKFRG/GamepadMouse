package com.gamepadmouse.shizuku;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.gamepadmouse.input.IInputInjector;

import java.util.concurrent.CopyOnWriteArrayList;

import rikka.shizuku.Shizuku;

/**
 * Shizuku 连接管理（Shizuku 13.x UserService 模型）：
 *  - 通过 Shizuku.bindUserService 让 ShellInputService 运行在 Shizuku 启动的独立进程中，
 *    该进程以 shell (UID 2000) / root (UID 0) 身份运行，可调用非 SDK API；
 *  - 断线自动重连（addBinderReceivedListenerSticky）；
 *  - 所有操作均做异常防护，任何一步失败都不会导致崩溃。
 */
public class ShizukuManager {

    private static final String TAG = "ShizukuManager";

    public interface StateListener {
        void onShizukuChanged(boolean ready);
    }

    private final Context mContext;
    private final Handler mHandler = new Handler(Looper.getMainLooper());
    private final CopyOnWriteArrayList<StateListener> mListeners = new CopyOnWriteArrayList<>();
    private final Shizuku.UserServiceArgs mServiceArgs;

    private volatile boolean mBound;
    private volatile IInputInjector mInjector;
    private boolean mListenerRegistered;
    private int mBindRetryCount;

    /** 最近一次绑定失败原因（供 UI 精确诊断） */
    private static volatile String sLastError;

    private final ServiceConnection mConn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            try {
                mInjector = IInputInjector.Stub.asInterface(service);
                mBound = true;
                sLastError = null;
                Log.i(TAG, "Shizuku input service connected");
                notifyChanged(true);
            } catch (Throwable t) {
                Log.e(TAG, "onServiceConnected error", t);
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.w(TAG, "Shizuku input service disconnected");
            mBound = false;
            mInjector = null;
            notifyChanged(false);
        }
    };

    /** Shizuku 服务重启/新连接时自动重连 */
    private final Shizuku.OnBinderReceivedListener mBinderListener = new Shizuku.OnBinderReceivedListener() {
        @Override
        public void onBinderReceived() {
            Log.i(TAG, "Shizuku binder received, rebind");
            mHandler.post(ShizukuManager.this::bind);
        }
    };

    public ShizukuManager(Context context) {
        mContext = context.getApplicationContext();
        mServiceArgs = new Shizuku.UserServiceArgs(
                new ComponentName(mContext, ShellInputService.class))
                .daemon(false)
                .processNameSuffix("input")
                .version(1);
    }

    public static boolean isShizukuAvailable() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean hasPermission() {
        try {
            return Shizuku.checkSelfPermission()
                    == android.content.pm.PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    public static void requestPermission(int requestCode) {
        try {
            Shizuku.requestPermission(requestCode);
        } catch (Throwable t) {
            Log.e(TAG, "requestPermission failed", t);
        }
    }

    public static boolean shouldShowRationale() {
        try {
            return Shizuku.shouldShowRequestPermissionRationale();
        } catch (Throwable t) {
            return false;
        }
    }

    /** 绑定 Shizuku 中的输入注入服务（幂等，失败自动重试 2 次） */
    public synchronized void bind() {
        if (mBound && mInjector != null) {
            sLastError = null;
            return;
        }
        // 关键：无论 Shizuku 当前是否可用，都先注册粘性监听器。
        // 这样用户“之后才启动 Shizuku”时，onBinderReceived 会回调本方法完成绑定。
        // （旧逻辑在不可用时直接 return，导致监听器从未注册、App 无法感知 Shizuku 启动）
        try {
            if (!mListenerRegistered) {
                Shizuku.addBinderReceivedListenerSticky(mBinderListener, mHandler);
                mListenerRegistered = true;
            }
        } catch (Throwable t) {
            Log.e(TAG, "addBinderReceivedListenerSticky failed", t);
        }
        if (!isShizukuAvailable()) {
            sLastError = "Shizuku 服务未运行";
            Log.i(TAG, "bind skipped: not available");
            return;
        }
        if (!hasPermission()) {
            sLastError = "Shizuku 未授权";
            Log.i(TAG, "bind skipped: no permission");
            return;
        }
        try {
            Shizuku.bindUserService(mServiceArgs, mConn);
            Log.i(TAG, "bindUserService requested");
            mBindRetryCount = 0;
        } catch (Throwable t) {
            Log.e(TAG, "bindUserService failed", t);
            mBound = false;
            mInjector = null;
            sLastError = "绑定失败：" + t.getClass().getSimpleName()
                    + "（大概率是 Shizuku 版本过旧，请更新到官网最新版 13+）";
            notifyChanged(false);
            // 自动重试（最多 2 次，间隔 800ms；Shizuku 刚启动/版本升级后常需重试）
            if (mBindRetryCount < 2) {
                mBindRetryCount++;
                mHandler.postDelayed(ShizukuManager.this::bind, 800L);
            }
        }
    }

    /** 最近一次绑定失败原因（供 UI 诊断） */
    public static String getLastError() {
        return sLastError;
    }

    /** 尝试读取 Shizuku 版本号；无法读取返回 -1（仅供 UI 显示） */
    public static int getShizukuVersion() {
        try {
            return Shizuku.getVersion();
        } catch (Throwable t) {
            return -1;
        }
    }

    public synchronized void unbind() {
        try {
            if (mBound) {
                Shizuku.unbindUserService(mServiceArgs, mConn, true);
            }
        } catch (Throwable t) {
            Log.e(TAG, "unbindUserService failed", t);
        }
        mBound = false;
        mInjector = null;
        mListeners.clear();
    }

    public boolean isReady() {
        return mBound && mInjector != null;
    }

    public IInputInjector getInjector() {
        return mInjector;
    }

    public void addListener(StateListener listener) {
        if (listener != null) {
            mListeners.add(listener);
        }
    }

    public void removeListener(StateListener listener) {
        mListeners.remove(listener);
    }

    private void notifyChanged(boolean ready) {
        for (StateListener l : mListeners) {
            try {
                l.onShizukuChanged(ready);
            } catch (Throwable ignored) {
            }
        }
    }

    public static boolean isShizukuInstalled(Context ctx) {
        try {
            Intent intent = new Intent("moe.shizuku.manager.intent.action.MAIN");
            return intent.resolveActivity(ctx.getPackageManager()) != null;
        } catch (Throwable t) {
            return false;
        }
    }

    public static Intent getShizukuGuideIntent() {
        return new Intent(Intent.ACTION_VIEW,
                android.net.Uri.parse("https://shizuku.rikka.app/zh-hans/guide/start/"));
    }
}
