package com.gamepadmouse.app.inject;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * 注入后端互斥选择逻辑单测 —— 两个后端永远不同时生效。
 */
public class BackendChooserTest {

    @Test
    public void shizukuReady_winsOverAccessibility() {
        // 双开场景：必须只选 Shizuku（真键优先），不会同时用无障碍
        assertEquals(BackendChooser.Choice.SHIZUKU,
                BackendChooser.choose(true, true));
    }

    @Test
    public void shizukuReady_only() {
        assertEquals(BackendChooser.Choice.SHIZUKU,
                BackendChooser.choose(true, false));
    }

    @Test
    public void accessibility_fallback() {
        assertEquals(BackendChooser.Choice.ACCESSIBILITY,
                BackendChooser.choose(false, true));
    }

    @Test
    public void none_whenNothingReady() {
        assertEquals(BackendChooser.Choice.NONE,
                BackendChooser.choose(false, false));
    }
}
