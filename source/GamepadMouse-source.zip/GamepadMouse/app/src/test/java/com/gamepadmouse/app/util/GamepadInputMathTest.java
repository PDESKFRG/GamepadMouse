package com.gamepadmouse.app.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * 手柄输入数学逻辑单测 —— 验证“鼠标模式可用”的核心数值逻辑。
 */
public class GamepadInputMathTest {

    @Test
    public void normalizeAxis_deadzone_returnsZero() {
        assertEquals(0f, GamepadInputMath.normalizeAxis(0f), 1e-6f);
        assertEquals(0f, GamepadInputMath.normalizeAxis(0.05f), 1e-6f);
        assertEquals(0f, GamepadInputMath.normalizeAxis(-0.05f), 1e-6f);
    }

    @Test
    public void normalizeAxis_positive_mapsTo01() {
        float v = GamepadInputMath.normalizeAxis(1f);
        assertTrue(v > 0f && v <= 1f);
        assertTrue(GamepadInputMath.normalizeAxis(0.8f) > 0f);
    }

    @Test
    public void normalizeAxis_negative_mirrorsPositive() {
        float p = GamepadInputMath.normalizeAxis(0.9f);
        float n = GamepadInputMath.normalizeAxis(-0.9f);
        assertEquals(-p, n, 1e-6f);
    }

    @Test
    public void normalizeAxis_clampsOutOfRange() {
        // 超界输入先钳到 [-1,1]，再归一化：输出最大不超过 1
        assertTrue(GamepadInputMath.normalizeAxis(2f) > 0f);
        assertTrue(GamepadInputMath.normalizeAxis(5f) <= 1f);
        assertTrue(GamepadInputMath.normalizeAxis(-5f) >= -1f);
        assertEquals(1f, GamepadInputMath.normalizeAxis(1f), 1e-6f);
    }

    @Test
    public void chooseRightStick_prefersRxRyWhenStronger() {
        float[] r = GamepadInputMath.chooseRightStick(0.9f, 0.1f, 0.05f, 0.05f);
        assertEquals(0.9f, r[0], 1e-6f);
        assertEquals(0.1f, r[1], 1e-6f);
    }

    @Test
    public void chooseRightStick_prefersZRzWhenStronger() {
        // 国产手柄：右摇杆实际在 Z/RZ 上（RX/RY 恒为 0）
        float[] r = GamepadInputMath.chooseRightStick(0f, 0f, 0.8f, 0.2f);
        assertEquals(0.8f, r[0], 1e-6f);
        assertEquals(0.2f, r[1], 1e-6f);
    }

    @Test
    public void chooseRightStick_tie_usesRxRy() {
        float[] r = GamepadInputMath.chooseRightStick(0.3f, 0.3f, 0.3f, 0.3f);
        assertEquals(0.3f, r[0], 1e-6f);
        assertEquals(0.3f, r[1], 1e-6f);
    }

    @Test
    public void clamp01_clamps() {
        assertEquals(0f, GamepadInputMath.clamp01(-1f), 0f);
        assertEquals(1f, GamepadInputMath.clamp01(2f), 0f);
        assertEquals(0.5f, GamepadInputMath.clamp01(0.5f), 0f);
    }

    @Test
    public void clampInt_clamps() {
        assertEquals(0, GamepadInputMath.clampInt(-3, 0, 10));
        assertEquals(10, GamepadInputMath.clampInt(99, 0, 10));
        assertEquals(5, GamepadInputMath.clampInt(5, 0, 10));
    }
}
